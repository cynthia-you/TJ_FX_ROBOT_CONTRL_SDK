﻿#pragma once
#include "afxdialogex.h"


// CTypeSelDlg 对话框

class CTypeSelDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CTypeSelDlg)

public:
	CTypeSelDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CTypeSelDlg();
	long m_settype;

	long m_type1;
	long m_type2;

	long m_useemg;
	long m_dfv;
	double m_dfa;
	double m_dfb;
	double m_dfc;

	long m_plr1;
	long m_plr2;
// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG2 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CButton cbt1;
	CButton cbt2;
	CButton cbt3;
	CButton cbt4;
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnBnClickedCheck2();
	afx_msg void OnBnClickedCheck3();
	afx_msg void OnBnClickedCheck4();
	CButton cbt5;
	CButton cbt6;
	CButton cbt7;
	CButton cbt8;
	CButton cbta;
	CButton cbtb;
	afx_msg void OnBnClickedCheckA();
	afx_msg void OnBnClickedCheckB();
	afx_msg void OnBnClickedCheck5();
	afx_msg void OnBnClickedCheck6();
	afx_msg void OnBnClickedCheck7();
	afx_msg void OnBnClickedCheck8();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCheckA2();
	CButton m_emg;
	CButton cbtc;
	afx_msg void OnBnClickedCheckA3();
	afx_msg void OnBnClickedCheckA4();
	CButton cbtd;
	CButton cbtE;
	afx_msg void OnBnClickedCheckA5();
	double m_gyro_A;
	double m_gyro_B;
	double m_gyro_C;
	CButton m_df;
	afx_msg void OnBnClickedCheckA6();
};
