﻿
// FxStationDlg.cpp: 实现文件
//

#include "pch.h"

#include "framework.h"
#include "FxStation.h"
#include "FxStationDlg.h"
#include "afxdialogex.h"

#include "CSelPVTDlg.h"

#include "CTypeSelDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


long  cyc_send_tag = 0;
long cyc_send_cnt = 0;

bool AscIIToHex(unsigned char ascbuf[256], long len, unsigned char hexbuf[256], long& retlen)
{
	unsigned char V = 0;
	retlen = 0;
	long cnt = 0;
	for (long i = 0; i < len; i++)
	{
		unsigned char c = ascbuf[i];
		unsigned char valid = 0;
		if (c >= '0' && c <= '9')
		{
			V *= 16;
			V += (c - '0');
			cnt++;
			valid = 1;
		}

		if (c >= 'a' && c <= 'f')
		{
			V *= 16;
			V += (10 + c - 'a');
			cnt++;
			valid = 1;
		}

		if (c >= 'A' && c <= 'F')
		{
			V *= 16;
			V += (10 + c - 'A');
			cnt++;
			valid = 1;
		}

		if (c == ' ')
		{
			valid = 1;
		}

		if (valid == 0)
		{
			return false;
		}
		if (cnt >= 3)
		{
			return false;
		}

		if (c == ' ' || i == len-1)
		{
			if (cnt != 0)
			{
				hexbuf[retlen] = V;
				retlen++;
				if (retlen >= 63)
				{
					return false;
				}
				cnt = 0;
				V = 0;
			}
		}
	}
	if (retlen <= 0)
	{
		return false;
	}
	return true;
}
// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnCbnDblclkCombo1();
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	ON_CBN_DBLCLK(IDC_COMBO1, &CAboutDlg::OnCbnDblclkCombo1)
END_MESSAGE_MAP()


// CFxStationDlg 对话框

FX_BOOL  LOADMvCfg(FX_CHAR* path, FX_INT32L TYPE[2], FX_DOUBLE GRV[2][3], FX_DOUBLE DH[2][8][4], FX_DOUBLE PNVA[2][7][4], FX_DOUBLE BD[2][4][3],
	FX_DOUBLE Mass[2][7], FX_DOUBLE MCP[2][7][3], FX_DOUBLE I[2][7][6])
{
	FX_INT32L i;
	FX_INT32L j;
	FX_CHAR   c;
	FILE* fp = fopen(path, "rb");
	if (fp == NULL)
	{
		return FX_FALSE;
	}

	for (i = 0; i < 2; i++)
	{
		if (fscanf(fp, "%ld,%lf,%lf,%lf,%c", &TYPE[i], &GRV[i][0], &GRV[i][1], &GRV[i][2], &c) != 5)
		{
			fclose(fp);
			return FX_FALSE;
		}
		if (c != 0x0a)
		{
			fclose(fp);
			return FX_FALSE;
		}

		for (j = 0; j < 7; j++)
		{
			if (fscanf(fp, "%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%c",
				&DH[i][j][0], &DH[i][j][1], &DH[i][j][2], &DH[i][j][3],
				&PNVA[i][j][1], &PNVA[i][j][0], &PNVA[i][j][2], &PNVA[i][j][3],
				&Mass[i][j], &MCP[i][j][0], &MCP[i][j][1], &MCP[i][j][2],
				&I[i][j][0], &I[i][j][1], &I[i][j][2], &I[i][j][3], &I[i][j][4], &I[i][j][5],
				&c) != 19)
			{
				fclose(fp);
				return FX_FALSE;
			}
			if (c != 0x0a)
			{
				fclose(fp);
				return FX_FALSE;
			}
		}

		if (fscanf(fp, "%lf,%lf,%lf,%lf,%c", &DH[i][7][0], &DH[i][7][1], &DH[i][7][2], &DH[i][7][3],
			&c) != 5)
		{
			fclose(fp);
			return FX_FALSE;
		}
		if (c != 0x0a)
		{
			fclose(fp);
			return FX_FALSE;
		}

		for (j = 0; j < 4; j++)
		{
			if (fscanf(fp, "%lf,%lf,%lf,%c",
				&BD[i][j][0], &BD[i][j][1], &BD[i][j][2], &c) != 4)
			{
				fclose(fp);
				return FX_FALSE;
			}
			if (c != 0x0a)
			{
				fclose(fp);
				return FX_FALSE;
			}
		}
	}

	fclose(fp);
	return FX_TRUE;
}


CFxStationDlg::CFxStationDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_FXSTATION_DIALOG, pParent)
	, m_tool_m(0)
	, m_cyc_joint_edit(_T(""))
	, m_cyc_file_1(_T(""))
	, m_cyc_file_2(_T(""))
	, m_work_pvt_serial_1(0)
	, m_sq_serial(0)
	, m_sq_offset(0)
	, m_work_pvt_serial_2(0)
	, m_Force(0)
	, m_ForceLmt(0)
	, m_EncSel(0)
	, m_Encoffset(0)
	, m_drg1(_T(""))
	, m_drg2(_T(""))
	, m_sendd_2_1(_T(""))
	, m_recv_2_1(_T(""))
	, m_sendd_2_2(_T(""))
	, m_recv_2_2(_T(""))
	, m_head1(0)
	, m_head2(0)
	, m_qlqc0(0)
	, m_qlqc1(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFxStationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_TOOL_M, m_Para.tool[0]);
	DDX_Text(pDX, IDC_EDIT_TOOL_MCPX, m_Para.tool[1]);
	DDX_Text(pDX, IDC_EDIT_TOOL_MCPY, m_Para.tool[2]);
	DDX_Text(pDX, IDC_EDIT_TOOL_MCPZ, m_Para.tool[3]);
	DDX_Text(pDX, IDC_EDIT_TOOL_IXX, m_Para.tool[4]);
	DDX_Text(pDX, IDC_EDIT_TOOL_IXY, m_Para.tool[5]);
	DDX_Text(pDX, IDC_EDIT_TOOL_IXZ, m_Para.tool[6]);
	DDX_Text(pDX, IDC_EDIT_TOOL_IYY, m_Para.tool[7]);
	DDX_Text(pDX, IDC_EDIT_TOOL_IYZ, m_Para.tool[8]);
	DDX_Text(pDX, IDC_EDIT_TOOL_IZZ, m_Para.tool[9]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_1, m_Para.tool[10]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_2, m_Para.tool[11]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_3, m_Para.tool[12]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_4, m_Para.tool[13]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_5, m_Para.tool[14]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_6, m_Para.tool[15]);
	DDX_Text(pDX, IDC_EDIT_JOINT_K_7, m_Para.tool[16]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_1, m_Para.tool[17]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_2, m_Para.tool[18]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_3, m_Para.tool[19]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_4, m_Para.tool[20]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_5, m_Para.tool[21]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_6, m_Para.tool[22]);
	DDX_Text(pDX, IDC_EDIT_JOINT_D_7, m_Para.tool[23]);
	DDX_Text(pDX, IDC_EDIT_CART_K_1, m_Para.tool[24]);
	DDX_Text(pDX, IDC_EDIT_CART_K_2, m_Para.tool[25]);
	DDX_Text(pDX, IDC_EDIT_CART_K_3, m_Para.tool[26]);
	DDX_Text(pDX, IDC_EDIT_CART_K_4, m_Para.tool[27]);
	DDX_Text(pDX, IDC_EDIT_CART_K_5, m_Para.tool[28]);
	DDX_Text(pDX, IDC_EDIT_CART_K_6, m_Para.tool[29]);
	DDX_Text(pDX, IDC_EDIT_CART_K_7, m_Para.tool[30]);
	DDX_Text(pDX, IDC_EDIT_CART_D_1, m_Para.tool[31]);
	DDX_Text(pDX, IDC_EDIT_CART_D_2, m_Para.tool[32]);
	DDX_Text(pDX, IDC_EDIT_CART_D_3, m_Para.tool[33]);
	DDX_Text(pDX, IDC_EDIT_CART_D_4, m_Para.tool[34]);
	DDX_Text(pDX, IDC_EDIT_CART_D_5, m_Para.tool[35]);
	DDX_Text(pDX, IDC_EDIT_CART_D_6, m_Para.tool[36]);
	DDX_Text(pDX, IDC_EDIT_CART_D_7, m_Para.tool[37]);
	DDX_Text(pDX, IDC_EDIT_VEL, m_Para.tool[38]);
	DDX_Text(pDX, IDC_EDIT_ACC, m_Para.tool[39]);
	DDX_Text(pDX, IDC_EDIT_TOOL_K_1, m_Para.tool[40]);
	DDX_Text(pDX, IDC_EDIT_TOOL_K_2, m_Para.tool[41]);
	DDX_Text(pDX, IDC_EDIT_TOOL_K_3, m_Para.tool[42]);
	DDX_Text(pDX, IDC_EDIT_TOOL_K_4, m_Para.tool[43]);
	DDX_Text(pDX, IDC_EDIT_TOOL_K_5, m_Para.tool[44]);
	DDX_Text(pDX, IDC_EDIT_TOOL_K_6, m_Para.tool[45]);
	DDX_Text(pDX, IDC_EDIT_ParaS, m_Paras.cur_use);

	DDX_Control(pDX, IDC_COMBO1, m_cb1);
	DDX_Control(pDX, IDC_COMBO2, m_cb2);
	DDX_Text(pDX, IDC_EDIT9, m_cyc_joint_edit);
	DDX_Text(pDX, IDC_EDIT7, m_cyc_file_1);
	DDX_Text(pDX, IDC_EDIT8, m_cyc_file_2);
	DDX_Control(pDX, IDC_IPADDRESS1, m_ip);
	DDX_Control(pDX, IDC_BUTTON_Link, m_linkbnt);
	DDX_Text(pDX, IDC_EDIT5, m_work_pvt_serial_1);
	DDX_Text(pDX, IDC_EDIT1, m_sq_serial);
	DDX_Text(pDX, IDC_EDIT2, m_sq_offset);
	DDX_Control(pDX, IDC_BUTTON6, m_bt6);
	DDX_Text(pDX, IDC_EDIT6, m_work_pvt_serial_2);
	DDX_Text(pDX, IDC_EDIT3, m_Force);
	DDX_Text(pDX, IDC_EDIT4, m_ForceLmt);
	DDX_Text(pDX, IDC_EDIT10, m_EncSel);
	DDX_Text(pDX, IDC_EDIT11, m_Encoffset);
	DDX_Text(pDX, IDC_EDIT_STATE_1, m_drg1);
	DDX_Text(pDX, IDC_EDIT_STATE_2, m_drg2);
	//  DDX_Control(pDX, IDC_EDIT12, m_sendd);
	//  DDX_Text(pDX, IDC_EDIT13, m_recvd);
	//  DDX_Text(pDX, IDC_EDIT12, m_sendd);
	DDX_Text(pDX, IDC_EDIT12, m_sendd_2_1);
	DDX_Text(pDX, IDC_EDIT13, m_recv_2_1);
	DDX_Text(pDX, IDC_EDIT15, m_sendd_2_2);
	DDX_Text(pDX, IDC_EDIT14, m_recv_2_2);
	DDX_Control(pDX, IDC_CHECK1, m_is_hex);
	DDX_Text(pDX, IDC_EDIT16, m_head1);
	DDX_Text(pDX, IDC_EDIT17, m_head2);
	DDX_Text(pDX, IDC_EDIT20, m_qlqc0);
	DDX_Text(pDX, IDC_EDIT21, m_qlqc1);
}

BEGIN_MESSAGE_MAP(CFxStationDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SetTool, &CFxStationDlg::OnBnClickedButtonSettool)
	ON_BN_CLICKED(IDC_BUTTON_Link, &CFxStationDlg::OnBnClickedButtonLink)
	ON_BN_CLICKED(IDC_BUTTON_PARA_SEL_1, &CFxStationDlg::OnBnClickedButtonParaSel1)
	ON_BN_CLICKED(IDC_BUTTON_PARA_SEL_2, &CFxStationDlg::OnBnClickedButtonParaSel2)
	ON_BN_CLICKED(IDC_BUTTON_TOOLSAVE, &CFxStationDlg::OnBnClickedButtonToolsave)
	ON_BN_CLICKED(IDC_BUTTON_TOOLLOAD, &CFxStationDlg::OnBnClickedButtonToolload)
	ON_BN_CLICKED(IDC_BUTTON_ADD_POINT_1, &CFxStationDlg::OnBnClickedButtonAddPoint1)
	ON_BN_CLICKED(IDC_BUTTON_ADD_POINT2, &CFxStationDlg::OnBnClickedButtonAddPoint2)
	ON_BN_CLICKED(IDC_BUTTON_DEL_POINT_1, &CFxStationDlg::OnBnClickedButtonDelPoint1)
	ON_BN_CLICKED(IDC_BUTTON_DEL_POINT_2, &CFxStationDlg::OnBnClickedButtonDelPoint2)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_POINT_1, &CFxStationDlg::OnBnClickedButtonSavePoint1)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_POINT_2, &CFxStationDlg::OnBnClickedButtonSavePoint2)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_POINT_2, &CFxStationDlg::OnBnClickedButtonLoadPoint2)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_POINT_1, &CFxStationDlg::OnBnClickedButtonLoadPoint1)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_CYC_FILE_1, &CFxStationDlg::OnBnClickedButtonLoadCycFile1)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_CYC_FILE_2, &CFxStationDlg::OnBnClickedButtonLoadCycFile2)
	ON_BN_CLICKED(IDC_BUTTON_SENDPVT_1, &CFxStationDlg::OnBnClickedButtonSendpvt1)
	ON_BN_CLICKED(IDC_BUTTON_SENDPVT_2, &CFxStationDlg::OnBnClickedButtonSendpvt2)
	ON_BN_CLICKED(IDC_BUTTON_WORK_PVT_1, &CFxStationDlg::OnBnClickedButtonWorkPvt1)
	ON_BN_CLICKED(IDC_BUTTON_WORK_PVT_2, &CFxStationDlg::OnBnClickedButtonWorkPvt2)
	ON_BN_CLICKED(IDC_BUTTON_WORK_PVT, &CFxStationDlg::OnBnClickedButtonWorkPvt)
	ON_BN_CLICKED(IDC_BUTTON_RUN_PVT_1, &CFxStationDlg::OnBnClickedButtonRunPvt1)
	ON_BN_CLICKED(IDC_BUTTON_WORK_JOINT_1, &CFxStationDlg::OnBnClickedButtonWorkJoint1)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD, &CFxStationDlg::OnBnClickedButtonSetjkd)
	ON_BN_CLICKED(IDC_BUTTON_SetCKD, &CFxStationDlg::OnBnClickedButtonSetckd)
	ON_BN_CLICKED(IDC_BUTTON_SetVelAcc, &CFxStationDlg::OnBnClickedButtonSetvelacc)
	ON_BN_CLICKED(IDC_BUTTON_RUN_J_TRACE_1, &CFxStationDlg::OnBnClickedButtonRunJTrace1)
	ON_BN_CLICKED(IDC_BUTTON_RUN_J_KD_1, &CFxStationDlg::OnBnClickedButtonRunJKd1)
	ON_BN_CLICKED(IDC_BUTTON2, &CFxStationDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CFxStationDlg::OnBnClickedButton3)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON4, &CFxStationDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CFxStationDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CFxStationDlg::OnBnClickedButton6)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CFxStationDlg::OnCbnSelchangeCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO2, &CFxStationDlg::OnCbnSelchangeCombo2)
	ON_CBN_DBLCLK(IDC_COMBO1, &CFxStationDlg::OnCbnDblclkCombo1)
	ON_BN_CLICKED(IDC_BUTTON7, &CFxStationDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON_WORK_CYCFILE_1, &CFxStationDlg::OnBnClickedButtonWorkCycfile1)
	ON_BN_CLICKED(IDC_BUTTON8, &CFxStationDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CFxStationDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON_RUN_C_KD_2, &CFxStationDlg::OnBnClickedButtonRunCKd2)
	ON_BN_CLICKED(IDC_BUTTON_RUN_J_KD_2, &CFxStationDlg::OnBnClickedButtonRunJKd2)
	ON_BN_CLICKED(IDC_BUTTON_RUN_C_KD_1, &CFxStationDlg::OnBnClickedButtonRunCKd1)
	ON_BN_CLICKED(IDC_BUTTON_RUN_PVT_2, &CFxStationDlg::OnBnClickedButtonRunPvt2)
	ON_BN_CLICKED(IDC_BUTTON_RUN_JOINT_TRACE_2, &CFxStationDlg::OnBnClickedButtonRunJointTrace2)
	ON_EN_CHANGE(IDC_EDIT6, &CFxStationDlg::OnEnChangeEdit6)
	ON_BN_CLICKED(IDC_BUTTON_WORK_JOINT_2, &CFxStationDlg::OnBnClickedButtonWorkJoint2)
	ON_BN_CLICKED(IDC_BUTTON10, &CFxStationDlg::OnBnClickedButton10)
	ON_BN_CLICKED(IDC_BUTTON11, &CFxStationDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON12, &CFxStationDlg::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &CFxStationDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON_RUN_FCTRL_1, &CFxStationDlg::OnBnClickedButtonRunFctrl1)
	ON_BN_CLICKED(IDC_BUTTON14, &CFxStationDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &CFxStationDlg::OnBnClickedButton15)
	ON_EN_CHANGE(IDC_EDIT11, &CFxStationDlg::OnEnChangeEdit11)
	ON_BN_CLICKED(IDC_BUTTON16, &CFxStationDlg::OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON17, &CFxStationDlg::OnBnClickedButton17)
	ON_BN_CLICKED(IDC_BUTTON18, &CFxStationDlg::OnBnClickedButton18)
	ON_BN_CLICKED(IDC_BUTTON19, &CFxStationDlg::OnBnClickedButton19)
	ON_BN_CLICKED(IDC_BUTTON20, &CFxStationDlg::OnBnClickedButton20)
	ON_EN_CHANGE(IDC_EDIT5, &CFxStationDlg::OnEnChangeEdit5)
	ON_BN_CLICKED(IDC_BUTTON21, &CFxStationDlg::OnBnClickedButton21)
	ON_BN_CLICKED(IDC_BUTTON22, &CFxStationDlg::OnBnClickedButton22)
	ON_BN_CLICKED(IDC_BUTTON24, &CFxStationDlg::OnBnClickedButton24)
	ON_BN_CLICKED(IDC_BUTTON23, &CFxStationDlg::OnBnClickedButton23)
	ON_BN_CLICKED(IDC_BUTTON25, &CFxStationDlg::OnBnClickedButton25)
	ON_BN_CLICKED(IDC_BUTTON26, &CFxStationDlg::OnBnClickedButton26)
	ON_BN_CLICKED(IDC_BUTTON27, &CFxStationDlg::OnBnClickedButton27)
	ON_BN_CLICKED(IDC_BUTTON28, &CFxStationDlg::OnBnClickedButton28)
	ON_BN_CLICKED(IDC_BUTTON29, &CFxStationDlg::OnBnClickedButton29)
	ON_BN_CLICKED(IDC_BUTTON30, &CFxStationDlg::OnBnClickedButton30)
	ON_BN_CLICKED(IDC_BUTTON31, &CFxStationDlg::OnBnClickedButton31)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD2, &CFxStationDlg::OnBnClickedButtonSetjkd2)
	ON_BN_CLICKED(IDC_BUTTON32, &CFxStationDlg::OnBnClickedButton32)
	ON_BN_CLICKED(IDC_BUTTON33, &CFxStationDlg::OnBnClickedButton33)
	ON_BN_CLICKED(IDC_BUTTON34, &CFxStationDlg::OnBnClickedButton34)
	ON_BN_CLICKED(IDC_BUTTON35, &CFxStationDlg::OnBnClickedButton35)
	ON_BN_CLICKED(IDC_BUTTON36, &CFxStationDlg::OnBnClickedButton36)
	ON_EN_CHANGE(IDC_EDIT_TOOL_M, &CFxStationDlg::OnEnChangeEditToolM)
	ON_EN_CHANGE(IDC_EDIT_TOOL_MCPX, &CFxStationDlg::OnEnChangeEditToolMcpx)
	ON_EN_CHANGE(IDC_EDIT3, &CFxStationDlg::OnEnChangeEdit3)
	ON_BN_CLICKED(IDC_BUTTON37, &CFxStationDlg::OnBnClickedButton37)
	ON_BN_CLICKED(IDC_BUTTON38, &CFxStationDlg::OnBnClickedButton38)
	ON_BN_CLICKED(IDC_BUTTON39, &CFxStationDlg::OnBnClickedButton39)
	ON_BN_CLICKED(IDC_BUTTON40, &CFxStationDlg::OnBnClickedButton40)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD3, &CFxStationDlg::OnBnClickedButtonSetjkd3)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD4, &CFxStationDlg::OnBnClickedButtonSetjkd4)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD5, &CFxStationDlg::OnBnClickedButtonSetjkd5)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD6, &CFxStationDlg::OnBnClickedButtonSetjkd6)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD7, &CFxStationDlg::OnBnClickedButtonSetjkd7)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD8, &CFxStationDlg::OnBnClickedButtonSetjkd8)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD9, &CFxStationDlg::OnBnClickedButtonSetjkd9)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD10, &CFxStationDlg::OnBnClickedButtonSetjkd10)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD11, &CFxStationDlg::OnBnClickedButtonSetjkd11)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD12, &CFxStationDlg::OnBnClickedButtonSetjkd12)
	ON_BN_CLICKED(IDC_BUTTON_SetJKD13, &CFxStationDlg::OnBnClickedButtonSetjkd13)
	ON_BN_CLICKED(IDC_UpdateSystemBtn, &CFxStationDlg::OnBnClickedUpdatesystembtn)
	ON_BN_CLICKED(IDC_DownloadLogBtn, &CFxStationDlg::OnBnClickedDownloadlogbtn)
		ON_BN_CLICKED(IDC_BUTTON_RUN_FCTRL_2, &CFxStationDlg::OnBnClickedButtonRunFctrl2)
		ON_BN_CLICKED(IDC_BUTTON42, &CFxStationDlg::OnBnClickedButton42)
		ON_BN_CLICKED(IDC_BUTTON_WORK_CYCFILE_2, &CFxStationDlg::OnBnClickedButtonWorkCycfile2)
		ON_BN_CLICKED(IDC_BUTTON_WORK_CYCFILE, &CFxStationDlg::OnBnClickedButtonWorkCycfile)
		ON_BN_CLICKED(IDC_BUTTON43, &CFxStationDlg::OnBnClickedButton43)
		ON_BN_CLICKED(IDC_BUTTON44, &CFxStationDlg::OnBnClickedButton44)
		ON_BN_CLICKED(IDC_BUTTON45, &CFxStationDlg::OnBnClickedButton45)
		ON_BN_CLICKED(IDC_BUTTON46, &CFxStationDlg::OnBnClickedButton46)
		ON_BN_CLICKED(IDC_BUTTON47, &CFxStationDlg::OnBnClickedButton47)
		ON_BN_CLICKED(IDC_BUTTON48, &CFxStationDlg::OnBnClickedButton48)
		ON_BN_CLICKED(IDC_UpdateSystemBtn2, &CFxStationDlg::OnBnClickedUpdatesystembtn2)
		ON_BN_CLICKED(IDC_CHECK1, &CFxStationDlg::OnBnClickedCheck1)
		ON_BN_CLICKED(IDC_BUTTON49, &CFxStationDlg::OnBnClickedButton49)
		ON_BN_CLICKED(IDC_BUTTON51, &CFxStationDlg::OnBnClickedButton51)
		ON_BN_CLICKED(IDC_BUTTON50, &CFxStationDlg::OnBnClickedButton50)
		ON_BN_CLICKED(IDC_BUTTON52, &CFxStationDlg::OnBnClickedButton52)
		ON_BN_CLICKED(IDC_BUTTON53, &CFxStationDlg::OnBnClickedButton53)
		ON_BN_CLICKED(IDC_BUTTON54, &CFxStationDlg::OnBnClickedButton54)
		ON_BN_CLICKED(IDC_BUTTON55, &CFxStationDlg::OnBnClickedButton55)
		ON_BN_CLICKED(IDC_BUTTON56, &CFxStationDlg::OnBnClickedButton56)
		ON_BN_CLICKED(IDC_BUTTON57, &CFxStationDlg::OnBnClickedButton57)
		ON_BN_CLICKED(IDC_BUTTON_RUN_J_TRACE_2, &CFxStationDlg::OnBnClickedButtonRunJTrace2)
		ON_EN_CHANGE(IDC_EDIT16, &CFxStationDlg::OnEnChangeEdit16)
		ON_BN_CLICKED(IDC_BUTTON58, &CFxStationDlg::OnBnClickedButton58)
		ON_BN_CLICKED(IDC_BUTTON59, &CFxStationDlg::OnBnClickedButton59)
		ON_BN_CLICKED(IDC_BUTTON_RUN_J_TRACE_3, &CFxStationDlg::OnBnClickedButtonRunJTrace3)
		ON_BN_CLICKED(IDC_BUTTON61, &CFxStationDlg::OnBnClickedButton61)
		ON_BN_CLICKED(IDC_BUTTON60, &CFxStationDlg::OnBnClickedButton60)
		ON_BN_CLICKED(IDC_BUTTON62, &CFxStationDlg::OnBnClickedButton62)
		ON_BN_CLICKED(IDC_BUTTON64, &CFxStationDlg::OnBnClickedButton64)
		ON_BN_CLICKED(IDC_BUTTON63, &CFxStationDlg::OnBnClickedButton63)
		ON_BN_CLICKED(IDC_BUTTON65, &CFxStationDlg::OnBnClickedButton65)
		ON_BN_CLICKED(IDC_BUTTON66, &CFxStationDlg::OnBnClickedButton66)
		ON_BN_CLICKED(IDC_BUTTON67, &CFxStationDlg::OnBnClickedButton67)
		ON_BN_CLICKED(IDC_BUTTON68, &CFxStationDlg::OnBnClickedButton68)
		END_MESSAGE_MAP()


// CFxStationDlg 消息处理程序

BOOL CFxStationDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	memset(&m_Para, 0, sizeof(SetPara));
	memset(&m_Paras, 0, sizeof(SetParas));

	m_Paras.cur_use = 1;


	m_Para.jk[0] = 2; 
	m_Para.jk[1] = 2; 
	m_Para.jk[2] = 2; 
	m_Para.jk[3] = 1.6; 
	m_Para.jk[4] = 1; 
	m_Para.jk[5] = 1; 
	m_Para.jk[6] = 1;

	m_Para.jd[0] = 0.6;
	m_Para.jd[1] = 0.6;
	m_Para.jd[2] = 0.6;
	m_Para.jd[3] = 0.4;
	m_Para.jd[4] = 0.2;
	m_Para.jd[5] = 0.2;
	m_Para.jd[6] = 0.2;


	m_Para.ck[0] = 3000;
	m_Para.ck[1] = 3000;
	m_Para.ck[2] = 3000;
	m_Para.ck[3] = 100;
	m_Para.ck[4] = 100;
	m_Para.ck[5] = 100;
	m_Para.ck[6] = 20;

	m_Para.cd[0] = 0.1;
	m_Para.cd[1] = 0.1;
	m_Para.cd[2] = 0.1;
	m_Para.cd[3] = 0.3;
	m_Para.cd[4] = 0.3;
	m_Para.cd[5] = 0.3;
	m_Para.cd[6] = 1;

	m_Para.vel = 20;
	m_Para.acc = 20;
	memcpy(&m_Paras.para[0], &m_Para, sizeof(m_Para));
	memcpy(&m_Paras.para[1], &m_Para, sizeof(m_Para));

	UpdateData(false);

	m_pset[0].OnInit(PotT_9d);
	m_pset[1].OnInit(PotT_9d);
	unsigned char ip1 = 192;
	unsigned char ip2 = 168;
	unsigned char ip3 = 1;
	unsigned char ip4 = 190;
	{
		FILE* fp = fopen("DGIP.CFG", "rb");
		if (fp != NULL)
		{
			long dip1, dip2, dip3, dip4;
			long scn = fscanf(fp, "[%d,%d,%d,%d]", &dip1, &dip2, &dip3, &dip4);
			if (scn == 4)
			{
				ip1 = dip1;
				ip2 = dip2;
				ip3 = dip3;
				ip4 = dip4;
			}
			fclose(fp);
		}
	}

	m_ip.SetAddress(ip1, ip2, ip3, ip4);
	m_LinkTag = false;

	m_TipDI_1 = -1;
	m_TipDI_2 = -1;

	m_LowSpdFlag_1 = -1;
	m_LowSpdFlag_2 = -1;

	HWND hDlg = GetSafeHwnd();
	hStatusWindow = CreateStatusWindow(WS_CHILD | WS_VISIBLE | WS_BORDER,
		TEXT("R1状态"),//显示在状态栏上的信息  
		hDlg, //父窗口句柄  
		102); //预定义的资源ID，相当于状态栏的ID号：GetDlgItem(IDS_STATUS)  

	int pint[6] = { 200,750,950,1650,1700,-1 };//状态栏第一个方格右边界离窗口客户区左边界的距离为100  
	//第二个方格右边界离窗口客户区左边界的距离为200  
	//...以此类推  
	//-1表示该方格的右边界为为窗口客户区的右边界  
	::SendMessage(hStatusWindow, SB_SETPARTS, 6, (LPARAM)pint);
	::SendMessage(hStatusWindow, SB_SETTEXT, 1, (LPARAM)TEXT("位置"));
	::SendMessage(hStatusWindow, SB_SETTEXT, 2, (LPARAM)TEXT("R2状态"));
	::SendMessage(hStatusWindow, SB_SETTEXT, 3, (LPARAM)TEXT("位置"));
	::SendMessage(hStatusWindow, SB_SETTEXT, 4, (LPARAM)TEXT("S"));
	::SendMessage(hStatusWindow, SB_SETTEXT, 5, (LPARAM)TEXT("S"));

	m_state_1B = -1;

	m_state_2B = -1;
	m_show_type = 0;
	this->SetTimer(1, 200, NULL);
	this->SetTimer(2, 20, NULL);
	this->SetTimer(3,10,NULL);



	old_bt_1 = 0;
	old_bt_2 = 0;
	m_pset_a1p50_tag = -2;
	m_pset_a2p50_tag = -2;


	in_dg_tag_1 = 0;
	in_dg_tag_2 = 0;

	in_gather_1 = false;
	in_gather_2 = false;
	ITT = false;
	m_ShowNum = 0;
	m_ShpwPos = 0;
	m_lmt_tag = false;
	m_hex_tag = false;


	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);


	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CFxStationDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CFxStationDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CFxStationDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CFxStationDlg::OnBnClickedButtonSettool()
{
	// TODO: 在此添加控件通知处理程序代码]
	if (m_LinkTag == false)
	{
		return;
	}
	double toolk[6];
	for (long i = 0; i < 6; i++)
	{
		toolk[i] = 0;
	}


	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);

	if (m_Paras.cur_use == 1)
	{
		CRobot::OnClearSet();
		CRobot::OnSetTool_A(m_Para.toolk, m_Para.tool);
		CRobot::OnSetSend();
	}


	if (m_Paras.cur_use == 2)
	{
		CRobot::OnClearSet();
		CRobot::OnSetTool_B(m_Para.toolk, m_Para.tool);
		CRobot::OnSetSend();
	}


}


void CFxStationDlg::OnBnClickedButtonLink()
{
	// TODO: 在此添加控件通知处理程序代码

	unsigned char ip1, ip2, ip3, ip4;
	m_ip.GetAddress(ip1, ip2, ip3, ip4);
	FILE* fp = fopen("DGIP.CFG", "wb");
	if (fp != NULL)
	{
		long dip1 = ip1;
		long dip2 = ip2;
		long dip3 = ip3;
		long dip4 = ip4;
		long scn = fprintf(fp, "[%d,%d,%d,%d]", dip1, dip2, dip3, dip4);
		fclose(fp);
	}

	if (CRobot::OnLinkTo(ip1, ip2, ip3, ip4) == false)
	{
		return;
	}

	m_linkbnt.EnableWindow(false);
	m_ip.EnableWindow(false);
	m_LinkTag = true;
}


bool CFxStationDlg::OnLoadParaFile(char* path)
{
	FILE* fp = fopen(path,"rb");
	if (fp == NULL)
	{
		return false;
	}

	char head[4];
	char vers[4];
	long s1 = fread(head, 1, 4, fp);
	long s2 = fread(vers, 1, 4, fp);

	if (s1 != 4 || s2 != 4)
	{
		fclose(fp);
		return false;
	}
	if (head[0] != 'F' || head[1] != 'P' || head[2] != 'R' || head[3] != 'A')
	{
		fclose(fp);
		return false;
	}
	if (vers[0] == 'V' && vers[1] == '0' && vers[2] == '0' && vers[3] == '2')
	{
		double paras[92];
		long i;
		for ( i = 0; i < 92; i++)
		{
			long s = fscanf(fp,"[%lf]",&paras[i]);
			if (s != 1)
			{
				fclose(fp);
				return false;
			}
		}

		fclose(fp);

		long pos = 0;
		{
			for (i = 0; i < 10; i++)
			{
				m_Paras.para[0].tool[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 7; i++)
			{
				m_Paras.para[0].jk[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 7; i++)
			{
				m_Paras.para[0].jd[i] = paras[pos];
				pos++;
			}

			for (i = 0; i < 7; i++)
			{
				m_Paras.para[0].ck[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 7; i++)
			{
				m_Paras.para[0].cd[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 6; i++)
			{
				m_Paras.para[0].toolk[i] = paras[pos];
				pos++;
			}
			m_Paras.para[0].vel = paras[pos];
			pos++;

			m_Paras.para[0].acc = paras[pos];
			pos++;
		}

		{
			for (i = 0; i < 10; i++)
			{
				m_Paras.para[1].tool[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 7; i++)
			{
				m_Paras.para[1].jk[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 7; i++)
			{
				m_Paras.para[1].jd[i] = paras[pos];
				pos++;
			}

			for (i = 0; i < 7; i++)
			{
				m_Paras.para[1].ck[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 7; i++)
			{
				m_Paras.para[1].cd[i] = paras[pos];
				pos++;
			}
			for (i = 0; i < 6; i++)
			{
				m_Paras.para[1].toolk[i] = paras[pos];
				pos++;
			}
			m_Paras.para[1].vel = paras[pos];
			pos++;

			m_Paras.para[1].acc = paras[pos];
			pos++;
		}
		
		return true;

	}
	else if (vers[0] == 'V' && vers[1] == '0' && vers[2] == '0' && vers[3] == '1')
		{
			double paras[80];
			long i;
			for (i = 0; i < 80; i++)
			{
				long s = fscanf(fp, "[%lf]", &paras[i]);
				if (s != 1)
				{
					fclose(fp);
					return false;
				}
			}

			fclose(fp);

			long pos = 0;
			{
				for (i = 0; i < 10; i++)
				{
					m_Paras.para[0].tool[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[0].jk[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[0].jd[i] = paras[pos];
					pos++;
				}

				for (i = 0; i < 7; i++)
				{
					m_Paras.para[0].ck[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[0].cd[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[0].toolk[i] = 0;
				}
				m_Paras.para[0].vel = paras[pos];
				pos++;

				m_Paras.para[0].acc = paras[pos];
				pos++;
			}

			{
				for (i = 0; i < 10; i++)
				{
					m_Paras.para[1].tool[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[1].jk[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[1].jd[i] = paras[pos];
					pos++;
				}

				for (i = 0; i < 7; i++)
				{
					m_Paras.para[1].ck[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[1].cd[i] = paras[pos];
					pos++;
				}
				for (i = 0; i < 7; i++)
				{
					m_Paras.para[1].toolk[i] = 0;
				}
				m_Paras.para[1].vel = paras[pos];
				pos++;

				m_Paras.para[1].acc = paras[pos];
				pos++;
			}

			return true;

	}
	else
	{
		fclose(fp);
		return false;
	}
	
	return false;
}






bool CFxStationDlg::OnSaveParaFile(char* path)
{
	FILE* fp = fopen(path, "wb");
	if (fp == NULL)
	{
		return false;
	}

	char head[4];
	char vers[4];
	head[0] = 'F';
	head[1] = 'P';
	head[2] = 'R';
	head[3] = 'A';


	vers[0] = 'V';
	vers[1] = '0';
	vers[2] = '0';
	vers[3] = '2';

	fwrite(head, 4, 1, fp);
	fwrite(vers, 4, 1, fp);


	double paras[92];
	long i;
	long pos = 0;
	{
		for (i = 0; i < 10; i++)
		{
			paras[pos] = m_Paras.para[0].tool[i];
			pos++;
		}
		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[0].jk[i];
			pos++;
		}
		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[0].jd[i];
			pos++;
		}

		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[0].ck[i];
			pos++;
		}
		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[0].cd[i];
			pos++;
		}
		for (i = 0; i < 6; i++)
		{
			paras[pos] = m_Paras.para[0].toolk[i];
			pos++;
		}
		paras[pos] = m_Paras.para[0].vel;
		pos++;

		paras[pos] = m_Paras.para[0].acc;
		pos++;
	}

	{
		for (i = 0; i < 10; i++)
		{
			paras[pos] = m_Paras.para[1].tool[i];
			pos++;
		}
		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[1].jk[i];
			pos++;
		}
		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[1].jd[i];
			pos++;
		}

		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[1].ck[i];
			pos++;
		}
		for (i = 0; i < 7; i++)
		{
			paras[pos] = m_Paras.para[1].cd[i];
			pos++;
		}
		for (i = 0; i < 6; i++)
		{
			paras[pos] = m_Paras.para[1].toolk[i];
			pos++;
		}
		paras[pos] = m_Paras.para[1].vel;
		pos++;

		paras[pos] = m_Paras.para[1].acc;
		pos++;
	}

	for ( i = 0; i < 92; i++)
	{
		fprintf(fp, "[%lf]", paras[i]);
	}
	fclose(fp);
	return true;
}

void CFxStationDlg::OnShowPara()
{

}


void CFxStationDlg::OnBnClickedButtonParaSel1()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);
	if (m_Paras.cur_use == 1)
	{
		memcpy(&m_Paras.para[0],&m_Para,sizeof(SetPara));
	}
	if (m_Paras.cur_use == 2)
	{
		memcpy(&m_Paras.para[1], &m_Para, sizeof(SetPara));
		m_Paras.cur_use = 1;
		memcpy(&m_Para, &m_Paras.para[0], sizeof(SetPara));
		UpdateData(false);

	}
	if (m_Paras.cur_use == 0)
	{
		UpdateData(true);
		m_Paras.cur_use = 1;
		memcpy(&m_Para, &m_Paras.para[0], sizeof(SetPara));
		UpdateData(false);
	}
	

}


void CFxStationDlg::OnBnClickedButtonParaSel2()
{
	if (m_Paras.cur_use == 2)
	{
		UpdateData(true);
		memcpy(&m_Paras.para[1], &m_Para, sizeof(SetPara));
	}
	if (m_Paras.cur_use == 1)
	{
		UpdateData(true);
		memcpy(&m_Paras.para[0], &m_Para, sizeof(SetPara));
		m_Paras.cur_use = 2;
		memcpy(&m_Para, &m_Paras.para[1], sizeof(SetPara));
		UpdateData(false);

	}

	if (m_Paras.cur_use == 0)
	{
		UpdateData(true);
		m_Paras.cur_use = 2;
		memcpy(&m_Para, &m_Paras.para[1], sizeof(SetPara));
		UpdateData(false);
	}
}


void CFxStationDlg::OnBnClickedButtonToolsave()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_Paras.cur_use == 0)
	{
		return;
	}

	if (m_Paras.cur_use == 1)
	{
		UpdateData(true);
		memcpy(&m_Paras.para[0], &m_Para, sizeof(SetPara));;
	}
	if (m_Paras.cur_use == 2)
	{
		UpdateData(true);
		memcpy(&m_Paras.para[1], &m_Para, sizeof(SetPara));;
	}

	CFileDialog fd(false, NULL, NULL, 0, ".FxPARAS|*.FxPARAS");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();
	if (s.Find(".FxPARAS") == -1)
	{
		s += ".FxPARAS";
	}

	if(OnSaveParaFile(s.GetBufferSetLength(s.GetLength() + 1)) == false)
	{
		AfxMessageBox("SaveParaFile ERR");
		return;
	}

}


void CFxStationDlg::OnBnClickedButtonToolload()
{
	CFileDialog fd(true, NULL, NULL, 0, ".FxPARAS|*.FxPARAS");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();

	if (OnLoadParaFile(s.GetBufferSetLength(s.GetLength() + 1)) == false)
	{
		AfxMessageBox("LoadParaFile ERR");
		return;
	}
	
	if (m_Paras.cur_use == 1)
	{
		memcpy(&m_Para, &m_Paras.para[0], sizeof(SetPara));
		UpdateData(false);
	}

	if (m_Paras.cur_use == 2)
	{
		memcpy(&m_Para, &m_Paras.para[1], sizeof(SetPara));
		UpdateData(false);
	}
}

bool OnGetLine(FILE* fp, char* buf)
{
	if (fp == NULL || buf == NULL)
	{
		return false;
	}

	buf[0] = '\0';
	char c = EOF;
	fread(&c, 1, 1, fp);
	long len = 0;
	while (c != EOF)
	{
		if (c != 0x0d && c != 0x0a)
		{
			buf[len] = c;
			len++;
			buf[len] = '\0';
			if (len > 1000)
			{
				return false;
			}
		}
		else
		{
			if (len != 0)
			{
				return true;
			}
		}
		c = EOF;
		fread(&c, 1, 1, fp);
	}

	return false;
}

bool OnGetValue(char* buf, double* retv, long& retn)
{
	long pos = 0;
	double tmp = 0;
	bool value_tag = false;
	long slen = strlen(buf);
	double dpos = 1;

	double min_v = 1;
	for (long i = 0; i < slen; i++)
	{
		char c = buf[i];

		if (c == '.' ||
			c == '-' ||
			c == '0' ||
			c == '1' ||
			c == '2' ||
			c == '3' ||
			c == '4' ||
			c == '5' ||
			c == '6' ||
			c == '7' ||
			c == '8' ||
			c == '9')
		{

			if (c == '.' || c == '-')
			{
				if (c == '-')
				{
					if (min_v < 0)
					{
						return false;
					}
					min_v = -1.0;
				}
				if (c == '.')
				{
					if (dpos < 0.7)
					{
						return false;
					}
					dpos = 0.1;
				}
			}
			else
			{
				double v = c - '0';
				if (dpos > 0.7)
				{
					tmp *= 10;
					tmp += v;
				}
				else
				{
					v *= dpos;
					tmp += v;
					dpos *= 0.1;
				}
				value_tag = true;
			}

		}
		else
		{
			if (value_tag == true)
			{
				retv[pos] = tmp * min_v;
				pos++;
				value_tag = false;
				dpos = 1.0;
				min_v = 1.0;
				tmp = 0;
			}

			if (c == 0x0d || c == 0x0a)
			{

				retn = pos;
				return true;
			}
		}
	}

	if (value_tag == true)
	{
		retv[pos] = tmp * min_v;
		pos++;
		value_tag = false;
		dpos = 1.0;
		min_v = 1.0;
	}

	retn = pos;
	return true;

}

void CFxStationDlg::OnBnClickedButtonAddPoint1()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);
	OnGetLmt();
	CString s = m_cyc_joint_edit;
	char* buf = s.GetBufferSetLength(s.GetLength() + 3);

	double sencv[100];
	long num = 10;
	if (OnGetValue(buf, sencv, num) == true)
	{
		if (num != 7)
		{
			AfxMessageBox("NEED 7 VALUE");
			return;
		}

		for (long i = 0; i < 7; i++)
		{
			if (sencv[i] < (m_RunLmt[0].m_pos_l[i] + 1.5))
			{
				CString s;
				s.Format("轴%d下限位 %lf（含边界）", i + 1, m_RunLmt[0].m_pos_l[i] + 1.5);
				AfxMessageBox(s);
				return;
			}
			if (sencv[i] > (m_RunLmt[0].m_pos_u[i] - 1.5))
			{
				CString s;
				s.Format("轴%d上限位 %lf（含边界）", i + 1, m_RunLmt[0].m_pos_u[i] - 1.5);
				AfxMessageBox(s);
				return;
			}
		}

		char sets[200];

		memset(sets, 0, 200);
		sprintf(sets, "%.2lf %.2lf %.2lf %.2lf %.2lf %.2lf %.2lf",
			sencv[0],
			sencv[1],
			sencv[2],
			sencv[3],
			sencv[4],
			sencv[5],
			sencv[6]);
		m_cb1.InsertString(0, sets);
		long numd = m_cb1.GetCount();
		m_cb1.SetCurSel(0);
		UpdateData(true);
	}
	else
	{
		AfxMessageBox("ERR FORMAT");
	}
}


void CFxStationDlg::OnBnClickedButtonAddPoint2()
{
	// TODO: 在此添加控件通知处理程序代码

	UpdateData(true);
	OnGetLmt();
	CString s = m_cyc_joint_edit;
	char* buf = s.GetBufferSetLength(s.GetLength() + 3);

	double sencv[100];
	long num = 10;
	if (OnGetValue(buf, sencv, num) == true)
	{
		if (num != 7)
		{
			AfxMessageBox("NEED 7 VALUE");
			return;
		}
		for (long i = 0; i < 7; i++)
		{
			if (sencv[i] < (m_RunLmt[1].m_pos_l[i] + 1.5))
			{
				CString s;
				s.Format("轴%d下限位 %lf（含边界）", i + 1, m_RunLmt[1].m_pos_l[i] + 1.5);
				AfxMessageBox(s);
				return;
			}
			if (sencv[i] > (m_RunLmt[1].m_pos_u[i] - 1.5))
			{
				CString s;
				s.Format("轴%d上限位 %lf（含边界）", i + 1, m_RunLmt[1].m_pos_u[i] - 1.5);
				AfxMessageBox(s);
				return;
			}
		}
		char sets[200];

		memset(sets, 0, 200);
		sprintf(sets, "%.2lf %.2lf %.2lf %.2lf %.2lf %.2lf %.2lf",
			sencv[0],
			sencv[1],
			sencv[2],
			sencv[3],
			sencv[4],
			sencv[5],
			sencv[6]);
		m_cb2.InsertString(0, sets);
		long numd = m_cb2.GetCount();
		m_cb2.SetCurSel(0);
		UpdateData(true);
	}
	else
	{
		AfxMessageBox("ERR FORMAT");
	}
}


void CFxStationDlg::OnBnClickedButtonDelPoint1()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);
	int sel = m_cb1.GetCurSel();
	if (sel == -1)
	{
		return;
	}
	m_cb1.DeleteString(sel);
	if (m_cb1.GetCount() != 0)
	{

		m_cb1.SetCurSel(0);
	}
	else
	{

		m_cb1.SetCurSel(-1);
	}
	UpdateData(true);
}


void CFxStationDlg::OnBnClickedButtonDelPoint2()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);
	int sel = m_cb2.GetCurSel();
	if (sel == -1)
	{
		return;
	}
	m_cb2.DeleteString(sel);
	if (m_cb2.GetCount() != 0)
	{

		m_cb2.SetCurSel(0);
	}
	else
	{

		m_cb2.SetCurSel(-1);
	}
	UpdateData(true);
}


void CFxStationDlg::OnBnClickedButtonSavePoint1()
{
	CFileDialog fd(false, NULL, NULL, 0, ".R1Points|*.R1Points");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();
	if (s.Find(".R1Points") == -1)
	{
		s += ".R1Points";
	}

	if (OnSavePointsFile(s.GetBufferSetLength(s.GetLength() + 1),1) == false)
	{
		AfxMessageBox("Save Points ERR");
		return;
	}
}



bool CFxStationDlg::OnLoadPointsFile(char* path, long target)
{

	OnGetLmt();

	long ts = 0;
	CComboBox* cb = NULL;
	if (target == 1)
	{
		cb = &m_cb1;
	}
	if (target == 2)
	{
		cb = &m_cb2;
		ts = 1;
	}

	if (cb == NULL)
	{
		return false;
	}

	FILE* fp = fopen(path,"rb");

	if (fp == NULL)
	{
		return false;
	}


	long num = cb->GetCount(); 
	long i;
	for ( i = 0; i < num; i++)
	{
		cb->DeleteString(0);
	}
	char buf[200];
	while (OnGetLine(fp, buf) == true)
	{
		double vs[10];
		long   vn = 10;
		if (OnGetValue(buf, vs, vn) == true)
		{
			if (vn == 7)
			{
				for (long ii = 0; ii < 7; ii++)
				{
					bool tk = false;
					if (vs[ii] < (m_RunLmt[ts].m_pos_l[ii] + 1.5))
					{
						CString s;
						s.Format("轴%d下限位 %lf（含边界）", ii + 1, m_RunLmt[ts].m_pos_l[ii] + 1.5);
						AfxMessageBox(s);
						tk = true;
					}
					if (vs[ii] > (m_RunLmt[ts].m_pos_u[ii] - 1.5))
					{
						CString s;
						s.Format("轴%d上限位 %lf（含边界）", ii + 1, m_RunLmt[ts].m_pos_u[ii] - 1.5);
						AfxMessageBox(s);
						tk = true;
					}

					if (tk)
					{
						num = cb->GetCount();
						for (i = 0; i < num; i++)
						{
							cb->DeleteString(0);
						}

						fclose(fp);
						return false;
					}
				}
				cb->AddString(buf);
			}
		}
	}

	fclose(fp);
	cb->SetCurSel(0);
	UpdateData(false);

	return true;
}
bool CFxStationDlg::OnSavePointsFile(char* path, long target)
{
	CComboBox* cb = NULL;
	if (target == 1)
	{
		cb = &m_cb1;
	}
	if (target == 2)
	{
		cb = &m_cb2;
	}

	if (cb == NULL)
	{
		return false;
	}

	long num = cb->GetCount();

	if (num == 0)
	{
		return false;
	}

	FILE* fp = fopen(path, "wb");

	if (fp == NULL)
	{
		return false;
	}


	long i;

	for (i = 0; i < num; i++)
	{
		CString s;
		cb->GetLBText(i,s);
		long size = s.GetLength();
		for (long k = 0; k < size; k++)
		{
			fprintf(fp,"%c",s.GetAt(k));
		}
		fprintf(fp, "%c%c",0x0d,0x0a);
	}
	
	fclose(fp);

	return true;
}


void CFxStationDlg::OnBnClickedButtonSavePoint2()
{
	CFileDialog fd(false, NULL, NULL, 0, ".R2Points|*.R2Points");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();
	if (s.Find(".R2Points") == -1)
	{
		s += ".R2Points";
	}

	if (OnSavePointsFile(s.GetBufferSetLength(s.GetLength() + 1),2) == false)
	{
		AfxMessageBox("Save Points ERR");
		return;
	}
}


void CFxStationDlg::OnBnClickedButtonLoadPoint2()
{
	CFileDialog fd(true, NULL, NULL, 0, ".R2Points|*.R2Points");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();
	
	if (OnLoadPointsFile(s.GetBufferSetLength(s.GetLength() + 1), 2) == false)
	{
		AfxMessageBox("Save Points ERR");
		return;
	}
}


void CFxStationDlg::OnBnClickedButtonLoadPoint1()
{
	CFileDialog fd(true, NULL, NULL, 0, ".R1Points|*.R1Points");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();


	if (OnLoadPointsFile(s.GetBufferSetLength(s.GetLength() + 1),1) == false)
	{
		AfxMessageBox(" Load Points ERR");
		return;
	}
}


void CFxStationDlg::OnBnClickedButtonLoadCycFile1()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_pset_a1p50_tag >=0)
	{
		return;
	}

	m_pset_a1p50_tag = -2;
	CFileDialog fd(true, NULL, NULL, 0, ".R1P50|*.R1P50");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	
	CString s = fd.GetPathName();
	CString s2 = s;
	
	m_cyc_file_1 = s;

	m_pset_a1p50.OnLoadFast(m_cyc_file_1.GetBufferSetLength(m_cyc_file_1.GetLength()+1));


	if (m_pset_a1p50.OnGetPointNum() > 30)
	{
		m_pset_a1p50_tag = -1;
	}

	UpdateData(false);

}


void CFxStationDlg::OnBnClickedButtonLoadCycFile2()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_pset_a2p50_tag >= 0)
	{
		return;
	}

	m_pset_a2p50_tag = -2;
	CFileDialog fd(true, NULL, NULL, 0, ".R2P50|*.R2P50");

	if (fd.DoModal() != IDOK)
	{
		return;
	}


	CString s = fd.GetPathName();
	CString s2 = s;

	m_cyc_file_2 = s;

	m_pset_a2p50.OnLoadFast(m_cyc_file_2.GetBufferSetLength(m_cyc_file_2.GetLength() + 1));


	if (m_pset_a2p50.OnGetPointNum() > 100)
	{
		m_pset_a2p50_tag = -1;
	}

	UpdateData(false);
}

bool CFxStationDlg::OnGetLmt()
{
	if (m_lmt_tag == true)
	{
		return true;
	}
	char name[30];

	long i;
	for ( i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.BASIC.LimitPos",i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[0].m_pos_u[i]);
	}

	for ( i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.BASIC.LimitNeg", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[0].m_pos_l[i]);
	}
	

	for (i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.BASIC.VelMax", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[0].m_vel[i]);
	}


	for (i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.BASIC.AccMax", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[0].m_acc[i]);
	}


	for (i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.BASIC.LimitPos", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[1].m_pos_u[i]);
	}

	for (i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.BASIC.LimitNeg", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[1].m_pos_l[i]);
	}


	for (i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.BASIC.VelMax", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[1].m_vel[i]);
	}


	for (i = 0; i < 7; i++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.BASIC.AccMax", i);
		CRobot::OnGetFloatPara(name, &m_RunLmt[1].m_acc[i]);
	}





	m_lmt_tag = true;


	return true;
}

bool CFxStationDlg::OnCheckPVT(long serial,CPointSet* pset, char* path)
{
	pset->OnEmpty();
	if (pset->OnLoadFast(path) == false)
	{
		return false;
	}
	long num = pset->OnGetPointNum();
	if (num < 100)
	{
		return false;
	}

	long i;
	double* pre;
	double* cur;
	double* nxt;
	long j;
	double vel1[7];
	double vel2[7];
	double acc[7];
	double vellmt[7];
	double acclmt[7];

	for ( j = 0; j < 7; j++)
	{
		vellmt[j] = m_RunLmt[serial].m_vel[j] * 0.002;
		acclmt[j] = m_RunLmt[serial].m_acc[j] * 0.002 * 0.002;
		vel1[j] = 0;
		vel2[j] = 0;
	}
	for ( i = 1; i < num; i++)
	{
		pre = pset->OnGetPoint(i - 1);
		cur = pset->OnGetPoint(i);
		for (j = 0; j < 7; j++)
		{
			vel2[j] = cur[j] - pre[j];

			if (vel2[j] < -vellmt[j] || vel2[j] > vellmt[j])
			{
				CString s;
				s.Format("文件 %d 行 关节%d 速度超限制",i,j);
				AfxMessageBox(s);
				pset->OnEmpty();
				return false;
			}
			acc[j] = vel2[j] - vel1[j];
			if (acc[j] < -acclmt[j] || acc[j] > acclmt[j])
			{
				CString s;
				s.Format("文件 %d 行 关节%d 加速度超限制",i,j );
				AfxMessageBox(s);
				pset->OnEmpty();
				return false;
			}
			vel1[j] = vel2[j];

			if (i == 1)
			{
				if (vel2[j] < -0.01 * vellmt[j] || vel2[j] > 0.01 * vellmt[j])
				{
					CString s;
					s.Format("开始 关节%d 速度 不为零（0.01 * 关节限制）", j);
					AfxMessageBox(s);
					pset->OnEmpty();
					return false;
				}

				if (acc[j] < -0.01 * acclmt[j] || acc[j] > 0.01 * acclmt[j])
				{
					CString s;
					s.Format("开始 关节%d 加速度 不为零（0.01 * 关节限制）", j);
					AfxMessageBox(s);
					pset->OnEmpty();
					return false;
				}
			}
		}

	}

	for (j = 0; j < 7; j++)
	{
		if (vel2[j] < -0.01 * vellmt[j] || vel2[j] > 0.01 * vellmt[j])
		{
			CString s;
			s.Format("文件结束行 关节%d 速度 不为零（0.01 * 关节限制）", j);
			AfxMessageBox(s);
			pset->OnEmpty();
			return false;
		}

		if (acc[j] < -0.01 * acclmt[j] || acc[j] > 0.01 * acclmt[j])
		{
			CString s;
			s.Format("文件结束行 关节%d 加速度 不为零（0.01 * 关节限制）", j);
			AfxMessageBox(s);
			pset->OnEmpty();
			return false;
		}
		
	}
	return true;;
}

void CFxStationDlg::OnBnClickedButtonSendpvt1()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	OnGetLmt();
	CSelPVTDlg dlg;
	if (dlg.DoModal() != IDOK)
	{
		return ;
	}
	long id = dlg.m_ID;
	CString s = dlg.m_Path;

	CPointSet pset;
	pset.OnInit(PotT_9d);

	CString s2 = s;
	if (OnCheckPVT(0, &pset, s2.GetBufferSetLength(s2.GetLength() + 1)) == false)
	{
		return;
	}

	CString local_file = s;
	CString remote_file;
	remote_file.Format("\/home\/FUSION\/Config\/pvt\/user0\/%d.txt", id);

	char* loc = local_file.GetBufferSetLength(local_file.GetLength() + 1);
	char* rmt = remote_file.GetBufferSetLength(remote_file.GetLength() + 1);


	if (CRobot::OnSendFile(loc, rmt) != true)
	{
		AfxMessageBox("SYNC FILE ERR");
		return;
	}

	AfxMessageBox("SYNC FILE OK");




}


void CFxStationDlg::OnBnClickedButtonSendpvt2()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	OnGetLmt();
	CSelPVTDlg dlg;
	if (dlg.DoModal() != IDOK)
	{
		return;
	}
	long id = dlg.m_ID;
	CString s = dlg.m_Path;

	CPointSet pset;
	pset.OnInit(PotT_9d);

	CString s2 = s;
	if (OnCheckPVT(1, &pset, s2.GetBufferSetLength(s2.GetLength() + 1)) == false)
	{
		return;
	}

	CString local_file = s;
	CString remote_file;
	remote_file.Format("\/home\/FUSION\/Config\/pvt\/user1\/%d.txt", id);

	char* loc = local_file.GetBufferSetLength(local_file.GetLength() + 1);
	char* rmt = remote_file.GetBufferSetLength(remote_file.GetLength() + 1);


	if (CRobot::OnSendFile(loc, rmt) != true)
	{
		AfxMessageBox("SYNC FILE ERR");
		return;
	}

	AfxMessageBox("SYNC FILE OK");

}


void CFxStationDlg::OnBnClickedButtonWorkPvt1()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetPVT_A(m_work_pvt_serial_1);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonWorkPvt2()
{
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetPVT_B(m_work_pvt_serial_2);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonWorkPvt()
{

	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetPVT_A(m_work_pvt_serial_1);
	CRobot::OnSetPVT_B(m_work_pvt_serial_2);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonRunPvt1()
{
	// TODO: 在此添加控件通知处理程序代码

	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_PVT);

	CRobot::OnSetSend();

}


void CFxStationDlg::OnBnClickedButtonWorkJoint1()
{
	// TODO: 在此添加控件通知处理程序代码

	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_cb1.GetCurSel();

	CString s;
	m_cb1.GetLBText(sel, s);

	OnGetLmt();
	char* buf = s.GetBufferSetLength(s.GetLength() + 3);

	double sencv[100];
	long num = 10;
	if (OnGetValue(buf, sencv, num) == true)
	{
		if (num != 7)
		{
			AfxMessageBox("NEED 7 VALUE");
			return;
		}
		for (long i = 0; i < 7; i++)
		{
			if (sencv[i] < (m_RunLmt[0].m_pos_l[i] + 1.5))
			{
				CString s;
				s.Format("轴%d下限位 %lf（含边界）", i + 1, m_RunLmt[0].m_pos_l[i] + 1.5);
				AfxMessageBox(s);
				return;
			}
			if (sencv[i] > (m_RunLmt[0].m_pos_u[i] + 1.5))
			{
				CString s;
				s.Format("轴%d上限位 %lf（含边界）", i + 1, m_RunLmt[0].m_pos_u[i] - 1.5);
				AfxMessageBox(s);
				return;
			}
		}
		CRobot::OnClearSet();
		CRobot::OnSetJointCmdPos_A(sencv);
		CRobot::OnSetSend();




	}



}


void CFxStationDlg::OnBnClickedButtonSetjkd()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	
	UpdateData(true);

	if (m_Paras.cur_use == 1)
	{
		CRobot::OnClearSet();
		CRobot::OnSetJointKD_A(m_Para.jk, m_Para.jd);
		CRobot::OnSetSend();
	}


	if (m_Paras.cur_use == 2)
	{
		CRobot::OnClearSet();
		CRobot::OnSetJointKD_B(m_Para.jk, m_Para.jd);
		CRobot::OnSetSend();
	}

	


}


void CFxStationDlg::OnBnClickedButtonSetckd()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);

	if (m_Paras.cur_use == 1)
	{
		CRobot::OnClearSet();
		CRobot::OnSetCartKD_A(m_Para.ck, m_Para.cd,0);
		CRobot::OnSetSend();
	}


	if (m_Paras.cur_use == 2)
	{
		CRobot::OnClearSet();
		CRobot::OnSetCartKD_B(m_Para.ck, m_Para.cd,0);
		CRobot::OnSetSend();
	}
}


void CFxStationDlg::OnBnClickedButtonSetvelacc()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);

	if (m_Paras.cur_use == 1)
	{
		CRobot::OnClearSet();
		CRobot::OnSetJointLmt_A(m_Para.vel, m_Para.acc);
		CRobot::OnSetSendWaitResponse(50);
	}


	if (m_Paras.cur_use == 2)
	{
		CRobot::OnClearSet();
		CRobot::OnSetJointLmt_B(m_Para.vel, m_Para.acc);
		CRobot::OnSetSendWaitResponse(100);
	}
}


void CFxStationDlg::OnBnClickedButtonRunJTrace1()
{
	// TODO: 在此添加控件通知处理程序代码

	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_POSITION);

	CRobot::OnSetSend();

}


void CFxStationDlg::OnBnClickedButtonRunJKd1()
{
	// TODO: 在此添加控件通知处理程序代码ARM_STATE_IMPD_JOINT
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_TORQ);
	CRobot::OnSetImpType_A(1);
	CRobot::OnSetSend();

}


void CFxStationDlg::OnBnClickedButton2()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_IDLE);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton3()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_B(ARM_STATE_IDLE);

	CRobot::OnSetSend();
}

void CFxStationDlg::OnSaveP50(long serial, CString s)
{
	CPointSet pset;
	if (pset.OnLoadFast((char*)"D:\\TMP\\station_gather.tmp") == false)
	{
		AfxMessageBox("Load File Err");
		return;
	}

	long num = pset.OnGetPointNum();

	CPointSet pset2;
	pset2.OnInit(PotT_9d);

	double v[9];

	for (long i = 0; i < num; i += 20)
	{
		double* pv = pset.OnGetPoint(i);
		v[0] = pv[2];
		v[1] = pv[3];
		v[2] = pv[4];
		v[3] = pv[5];
		v[4] = pv[6];
		v[5] = pv[7];
		v[6] = pv[8];
		v[7] = 0;
		v[8] = 0;
		pset2.OnSetPoint(v);
	}
	if (pset2.OnSave(s.GetBufferSetLength(s.GetLength()+1)) == false)
	{
		AfxMessageBox("Save ERR");
		return;
	}
}
void CFxStationDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	if (nIDEvent == 3 && cyc_send_tag == 1)
	{
		cyc_send_cnt++;
		char send_buf[200];
		sprintf(send_buf, "___TestSend%d ", cyc_send_cnt);
		long len = strlen(send_buf);
		CRobot::OnSetChDataB((unsigned char *)send_buf, len, 3);
	}
	if (nIDEvent == 2)
	{
		if (m_pset_a1p50_tag >= 0 && m_pset_a2p50_tag < 0)
		{
			double* pvv = m_pset_a1p50.OnGetPoint(m_pset_a1p50_tag);
			if (pvv == NULL)
			{
				m_pset_a1p50_tag = -1;
			}
			else
			{
				CRobot::OnClearSet();
				CRobot::OnSetJointCmdPos_A(pvv);
				CRobot::OnSetSend();
				m_pset_a1p50_tag++;
			}

			CString s;
			
			s.Format("SA%d SB-1", m_pset_a1p50_tag);
			::SendMessage(hStatusWindow, SB_SETTEXT, 4, (LPARAM)TEXT(s.GetBufferSetLength(s.GetLength() + 1)));

		}
		else if (m_pset_a2p50_tag >= 0 && m_pset_a1p50_tag < 0)
		{
			double* pvv = m_pset_a2p50.OnGetPoint(m_pset_a2p50_tag);
			if (pvv == NULL)
			{
				m_pset_a2p50_tag = -1;
			}
			else
			{
				CRobot::OnClearSet();
				CRobot::OnSetJointCmdPos_B(pvv);
				CRobot::OnSetSend();
				m_pset_a2p50_tag++;
			}

			CString s;

			s.Format("SA-1 SB%d", m_pset_a2p50_tag);
			::SendMessage(hStatusWindow, SB_SETTEXT, 4, (LPARAM)TEXT(s.GetBufferSetLength(s.GetLength() + 1)));

		}


		else if (m_pset_a2p50_tag >= 0 && m_pset_a1p50_tag  >= 0)
		{
			double* pvv1 = m_pset_a1p50.OnGetPoint(m_pset_a1p50_tag);
			double* pvv2 = m_pset_a2p50.OnGetPoint(m_pset_a2p50_tag);

			CRobot::OnClearSet();


			if (pvv1 == NULL)
			{
				m_pset_a1p50_tag = -1;
			}
			else
			{
				
				CRobot::OnSetJointCmdPos_A(pvv1);
		
				m_pset_a1p50_tag++;
			}


			if (pvv2 == NULL)
			{
				m_pset_a2p50_tag = -1;
			}
			else
			{
				CRobot::OnSetJointCmdPos_B(pvv2);
				
				m_pset_a2p50_tag++;
			}

			if (m_pset_a1p50_tag != -1 || m_pset_a2p50_tag != -1)
			{
				CRobot::CRobot::OnSetSend();
			}

			CString s;


			s.Format("SA%d SB%d", m_pset_a1p50_tag, m_pset_a2p50_tag);
			::SendMessage(hStatusWindow, SB_SETTEXT, 4, (LPARAM)TEXT(s.GetBufferSetLength(s.GetLength() + 1)));

		}


		
	}
	if (nIDEvent == 1 && ITT == false)
	{
		ITT = true;
		if (m_LinkTag == true)
		{
			DCSS t;
			if (CRobot::OnGetBuf(&t) == true)
			{
				if (1)
				{

				if (old_bt_1 == 0 && t.m_Out[0].m_TipDI == 1)
				{
					if (in_dg_tag_1 !=0 && in_gather_1 == false && in_gather_2 == false)
					{
						long targetID[35];
						targetID[0] = 0;
						targetID[1] = 1;
						targetID[2] = 2;
						targetID[3] = 3;
						targetID[4] = 4;
						targetID[5] = 5;
						targetID[6] = 6;
						CRobot::OnStartGather(7, targetID, 100000);
						in_gather_1 = true;
					}
					old_bt_1 = t.m_Out[0].m_TipDI;
				}
				else if(old_bt_1 == 1 && t.m_Out[0].m_TipDI == 0)
				{
					if (in_gather_1 == true)
					{
						CRobot::OnStopGather();
						CFileDialog fd(false, NULL, NULL, 0, ".R1P50|*.R1P50");

						if (fd.DoModal() == IDOK)
						{
							CString s = fd.GetPathName();

							if (s.Find(".R1P50") == -1)
							{
								s += ".R1P50";
							}
							CRobot::OnSaveGatherData((char*)"D:\\TMP\\station_gather.tmp");
							OnSaveP50(0,s);
						}
						
						in_gather_1 = false;
					}
					old_bt_1 = t.m_Out[0].m_TipDI;
				}
				else
				{
					old_bt_1 = t.m_Out[0].m_TipDI;
				}


				if (t.m_In[0].m_DragSpType != in_dg_tag_1)
				{

					in_dg_tag_1 = t.m_In[0].m_DragSpType;
					if (in_dg_tag_1 == 0)
					{
						m_drg1 = "";
					}
					else if (in_dg_tag_1 == 1)
					{
						m_drg1 = "J";
					}
					else if (in_dg_tag_1 == 2)
					{
						m_drg1 = "XYZ";
					}
					else if (in_dg_tag_1 == 3)
					{
						m_drg1 = "ABC";
					}
					UpdateData(false);
				}

				//////////////////////////////////////////////////////


				if (old_bt_2 == 0 && t.m_Out[1].m_TipDI == 1)
				{
					if (in_dg_tag_2 != 0 && in_gather_1 == false && in_gather_2 == false)
					{
						long targetID[35];
						targetID[0] = 100;
						targetID[1] = 101;
						targetID[2] = 102;
						targetID[3] = 103;
						targetID[4] = 104;
						targetID[5] = 105;
						targetID[6] = 106;
						CRobot::OnStartGather(7, targetID, 100000);
						in_gather_2 = true;
					}
					old_bt_2 = t.m_Out[1].m_TipDI;
				}
				else if (old_bt_2 == 1 && t.m_Out[1].m_TipDI == 0)
				{
					if (in_gather_2 == true)
					{
						CRobot::OnStopGather();
						CFileDialog fd(false, NULL, NULL, 0, ".R2P50|*.R2P50");

						if (fd.DoModal() == IDOK)
						{
							CString s = fd.GetPathName();
							if (s.Find(".R2P50") == -1)
							{
								s += ".R2P50";
							}
							CRobot::OnSaveGatherData((char*)"D:\\TMP\\station_gather.tmp");
							OnSaveP50(0, s);
						}

						in_gather_2 = false;
					}
					old_bt_2 = t.m_Out[1].m_TipDI;
				}
				else
				{
					old_bt_2 = t.m_Out[1].m_TipDI;
				}


				if (t.m_In[1].m_DragSpType != in_dg_tag_2)
				{

					in_dg_tag_2 = t.m_In[1].m_DragSpType;
					if (in_dg_tag_2 == 0)
					{
						m_drg2 = "";
					}
					else if (in_dg_tag_2 == 1)
					{
						m_drg2 = "J";
					}
					else if (in_dg_tag_2 == 2)
					{
						m_drg2 = "XYZ";
					}
					else if (in_dg_tag_2 == 3)
					{
						m_drg2 = "ABC";
					}
					UpdateData(false);
				}

				}
				///////////////////////////////////////////////////////////////////

				FX_INT32 state_1B = t.m_State[0].m_CurState;
				FX_INT32 state_2B = t.m_State[1].m_CurState;
				
				if (state_1B != m_state_1B || m_TipDI_1 != t.m_Out[0].m_TipDI || m_LowSpdFlag_1 != t.m_Out[0].m_LowSpdFlag)
				{
					m_LowSpdFlag_1 = t.m_Out[0].m_LowSpdFlag;
					m_TipDI_1 = t.m_Out[0].m_TipDI;
					CString sa;
					sa.Format("<%d,%d>", t.m_Out[0].m_TipDI, t.m_Out[0].m_LowSpdFlag);
					m_state_1B = state_1B;

					CString s;
					if (m_state_1B == ARM_STATE_IDLE)
					{
						s.Format("下使能");
					}
					else if (m_state_1B == ARM_STATE_POSITION)
					{
						s.Format("位置跟踪");
					}
					else if (m_state_1B == ARM_STATE_PVT)
					{
						s.Format("位置PVT");
					}
					else if (m_state_1B == ARM_STATE_TORQ)
					{
						s.Format("扭矩模式");
					}
					else if (m_state_1B == 8)
					{
						s.Format("未定义");
					}
					else
					{
						
						s.Format("<%d>", t.m_State[0].m_ERRCode);
						CString tse;
						if (t.m_State[0].m_ERRCode == 1) { tse = "总线拓扑异常"; }
						if (t.m_State[0].m_ERRCode == 2) { tse = "伺服故障"; }
						if (t.m_State[0].m_ERRCode == 3) { tse = "PVT异常"; }
						if (t.m_State[0].m_ERRCode == 4) { tse = "请求进位置失败"; }
						if (t.m_State[0].m_ERRCode == 5) { tse = "进位置失败"; }
						if (t.m_State[0].m_ERRCode == 6) { tse = "请求进扭矩失败"; }
						if (t.m_State[0].m_ERRCode == 7) { tse = "进扭矩失败"; }
						if (t.m_State[0].m_ERRCode == 8) { tse = "请求上伺服失败"; }
						if (t.m_State[0].m_ERRCode == 9) { tse = "上伺服失败"; }
						if (t.m_State[0].m_ERRCode == 10) { tse = "请求下伺服失败"; }
						if (t.m_State[0].m_ERRCode == 11) { tse = "下伺服失败"; }
						if (t.m_State[0].m_ERRCode == 12) { tse = "内部错"; }
						if (t.m_State[0].m_ERRCode == 13) { tse = "急停"; }

						s += tse;
					}

					sa += s;
					::SendMessage(hStatusWindow, SB_SETTEXT, 0, (LPARAM)TEXT(sa.GetBufferSetLength(sa.GetLength() + 1)));
				}

				if (state_2B != m_state_2B || m_TipDI_2 != t.m_Out[1].m_TipDI || m_LowSpdFlag_2 != t.m_Out[1].m_LowSpdFlag)
				{
					m_LowSpdFlag_2 = t.m_Out[1].m_LowSpdFlag;
					m_TipDI_2 = t.m_Out[1].m_TipDI;
					CString sb;
					sb.Format("<%d,%d>", t.m_Out[1].m_TipDI, t.m_Out[1].m_LowSpdFlag);
					m_state_2B = state_2B;

					CString s;
					if (m_state_2B == ARM_STATE_IDLE)
					{
						s.Format("下使能");
					}
					else if (m_state_2B == ARM_STATE_POSITION)
					{
						s.Format("位置跟踪");
					}
					else if (m_state_2B == ARM_STATE_PVT)
					{
						s.Format("位置PVT");
					}
					else if (m_state_2B == ARM_STATE_TORQ)
					{
						s.Format("扭矩模式");
					}
					else if (m_state_2B == 8)
					{
						s.Format("未定义");
					}
					else
					{
						s.Format("<%d>", t.m_State[1].m_ERRCode);

						CString tse;
						if (t.m_State[1].m_ERRCode == 1) { tse = "总线拓扑异常"; }
						if (t.m_State[1].m_ERRCode == 2) { tse = "伺服故障"; }
						if (t.m_State[1].m_ERRCode == 3) { tse = "PVT异常"; }
						if (t.m_State[1].m_ERRCode == 4) { tse = "请求进位置失败"; }
						if (t.m_State[1].m_ERRCode == 5) { tse = "进位置失败"; }
						if (t.m_State[1].m_ERRCode == 6) { tse = "请求进扭矩失败"; }
						if (t.m_State[1].m_ERRCode == 7) { tse = "进扭矩失败"; }
						if (t.m_State[1].m_ERRCode == 8) { tse = "请求上伺服失败"; }
						if (t.m_State[1].m_ERRCode == 9) { tse = "上伺服失败"; }
						if (t.m_State[1].m_ERRCode == 10) { tse = "请求下伺服失败"; }
						if (t.m_State[1].m_ERRCode == 11) { tse = "下伺服失败"; }
						if (t.m_State[1].m_ERRCode == 12) { tse = "内部错"; }
						if (t.m_State[1].m_ERRCode == 13) { tse = "急停"; }

						s += tse;
					}
					sb += s;
					::SendMessage(hStatusWindow, SB_SETTEXT, 2, (LPARAM)TEXT(sb.GetBufferSetLength(sb.GetLength() + 1)));
				}

				{
					CString s;
					if (m_show_type == 0)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_FB_Joint_Pos[0],
							t.m_Out[0].m_FB_Joint_Pos[1],
							t.m_Out[0].m_FB_Joint_Pos[2],
							t.m_Out[0].m_FB_Joint_Pos[3],
							t.m_Out[0].m_FB_Joint_Pos[4],
							t.m_Out[0].m_FB_Joint_Pos[5],
							t.m_Out[0].m_FB_Joint_Pos[6]);

					}
					else if (m_show_type == 1)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_FB_Joint_Vel[0],
							t.m_Out[0].m_FB_Joint_Vel[1],
							t.m_Out[0].m_FB_Joint_Vel[2],
							t.m_Out[0].m_FB_Joint_Vel[3],
							t.m_Out[0].m_FB_Joint_Vel[4],
							t.m_Out[0].m_FB_Joint_Vel[5],
							t.m_Out[0].m_FB_Joint_Vel[6]);

					}
					else if (m_show_type == 2)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_FB_Joint_SToq[0],
							t.m_Out[0].m_FB_Joint_SToq[1],
							t.m_Out[0].m_FB_Joint_SToq[2],
							t.m_Out[0].m_FB_Joint_SToq[3],
							t.m_Out[0].m_FB_Joint_SToq[4],
							t.m_Out[0].m_FB_Joint_SToq[5],
							t.m_Out[0].m_FB_Joint_SToq[6]);

					}
					else if (m_show_type == 3)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_FB_Joint_CToq[0],
							t.m_Out[0].m_FB_Joint_CToq[1],
							t.m_Out[0].m_FB_Joint_CToq[2],
							t.m_Out[0].m_FB_Joint_CToq[3],
							t.m_Out[0].m_FB_Joint_CToq[4],
							t.m_Out[0].m_FB_Joint_CToq[5],
							t.m_Out[0].m_FB_Joint_CToq[6]);

					}
					else if (m_show_type == 4)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_FB_Joint_Them[0],
							t.m_Out[0].m_FB_Joint_Them[1],
							t.m_Out[0].m_FB_Joint_Them[2],
							t.m_Out[0].m_FB_Joint_Them[3],
							t.m_Out[0].m_FB_Joint_Them[4],
							t.m_Out[0].m_FB_Joint_Them[5],
							t.m_Out[0].m_FB_Joint_Them[6]);

					}
					else if (m_show_type == 5)
					{
						s.Format("%.2lf %.2lf %.2lf %.2lf %.2lf %.2lf %.2lf <%.1lf %.1lf %.1lf %.1lf %.1lf %.1lf %.1lf >",
							t.m_Out[0].m_FB_Joint_Pos[0],
							t.m_Out[0].m_FB_Joint_Pos[1],
							t.m_Out[0].m_FB_Joint_Pos[2],
							t.m_Out[0].m_FB_Joint_Pos[3],
							t.m_Out[0].m_FB_Joint_Pos[4],
							t.m_Out[0].m_FB_Joint_Pos[5],
							t.m_Out[0].m_FB_Joint_Pos[6],
							t.m_Out[0].m_FB_Joint_PosE[0],
							t.m_Out[0].m_FB_Joint_PosE[1],
							t.m_Out[0].m_FB_Joint_PosE[2],
							t.m_Out[0].m_FB_Joint_PosE[3],
							t.m_Out[0].m_FB_Joint_PosE[4],
							t.m_Out[0].m_FB_Joint_PosE[5],
							t.m_Out[0].m_FB_Joint_PosE[6]);

					}
					else if (m_show_type == 6)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_FB_Joint_Cmd[0],
							t.m_Out[0].m_FB_Joint_Cmd[1],
							t.m_Out[0].m_FB_Joint_Cmd[2],
							t.m_Out[0].m_FB_Joint_Cmd[3],
							t.m_Out[0].m_FB_Joint_Cmd[4],
							t.m_Out[0].m_FB_Joint_Cmd[5],
							t.m_Out[0].m_FB_Joint_Cmd[6]);

					}
					else
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[0].m_EST_Joint_Force[0],
							t.m_Out[0].m_EST_Joint_Force[1],
							t.m_Out[0].m_EST_Joint_Force[2],
							t.m_Out[0].m_EST_Joint_Force[3],
							t.m_Out[0].m_EST_Joint_Force[4],
							t.m_Out[0].m_EST_Joint_Force[5],
							t.m_Out[0].m_EST_Joint_Force[6]);
					}
					

					::SendMessage(hStatusWindow, SB_SETTEXT, 1, (LPARAM)TEXT(s.GetBufferSetLength(s.GetLength() + 1)));
				}


				{
					CString s;
					if (m_show_type == 0)
					{
						s.Format("% .3lf % .3lf % .3lf % .3lf % .3lf % .3lf % .3lf ",
							t.m_Out[1].m_FB_Joint_Pos[0],
							t.m_Out[1].m_FB_Joint_Pos[1],
							t.m_Out[1].m_FB_Joint_Pos[2],
							t.m_Out[1].m_FB_Joint_Pos[3],
							t.m_Out[1].m_FB_Joint_Pos[4],
							t.m_Out[1].m_FB_Joint_Pos[5],
							t.m_Out[1].m_FB_Joint_Pos[6]);

					}
					else if (m_show_type == 1)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[1].m_FB_Joint_Vel[0],
							t.m_Out[1].m_FB_Joint_Vel[1],
							t.m_Out[1].m_FB_Joint_Vel[2],
							t.m_Out[1].m_FB_Joint_Vel[3],
							t.m_Out[1].m_FB_Joint_Vel[4],
							t.m_Out[1].m_FB_Joint_Vel[5],
							t.m_Out[1].m_FB_Joint_Vel[6]);

					}
					else if (m_show_type == 2)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[1].m_FB_Joint_SToq[0],
							t.m_Out[1].m_FB_Joint_SToq[1],
							t.m_Out[1].m_FB_Joint_SToq[2],
							t.m_Out[1].m_FB_Joint_SToq[3],
							t.m_Out[1].m_FB_Joint_SToq[4],
							t.m_Out[1].m_FB_Joint_SToq[5],
							t.m_Out[1].m_FB_Joint_SToq[6]);

					}
					else if (m_show_type == 3)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[1].m_FB_Joint_CToq[0],
							t.m_Out[1].m_FB_Joint_CToq[1],
							t.m_Out[1].m_FB_Joint_CToq[2],
							t.m_Out[1].m_FB_Joint_CToq[3],
							t.m_Out[1].m_FB_Joint_CToq[4],
							t.m_Out[1].m_FB_Joint_CToq[5],
							t.m_Out[1].m_FB_Joint_CToq[6]);

					}
					else if (m_show_type == 4)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[1].m_FB_Joint_Them[0],
							t.m_Out[1].m_FB_Joint_Them[1],
							t.m_Out[1].m_FB_Joint_Them[2],
							t.m_Out[1].m_FB_Joint_Them[3],
							t.m_Out[1].m_FB_Joint_Them[4],
							t.m_Out[1].m_FB_Joint_Them[5],
							t.m_Out[1].m_FB_Joint_Them[6]);

					}
					else if (m_show_type == 5)
					{
						s.Format("%.2lf %.2lf %.2lf %.2lf %.2lf %.2lf %.2lf <%.1lf %.1lf %.1lf %.1lf %.1lf %.1lf %.1lf >",
							t.m_Out[1].m_FB_Joint_Pos[0],
							t.m_Out[1].m_FB_Joint_Pos[1],
							t.m_Out[1].m_FB_Joint_Pos[2],
							t.m_Out[1].m_FB_Joint_Pos[3],
							t.m_Out[1].m_FB_Joint_Pos[4],
							t.m_Out[1].m_FB_Joint_Pos[5],
							t.m_Out[1].m_FB_Joint_Pos[6],
							t.m_Out[1].m_FB_Joint_PosE[0],
							t.m_Out[1].m_FB_Joint_PosE[1],
							t.m_Out[1].m_FB_Joint_PosE[2],
							t.m_Out[1].m_FB_Joint_PosE[3],
							t.m_Out[1].m_FB_Joint_PosE[4],
							t.m_Out[1].m_FB_Joint_PosE[5],
							t.m_Out[1].m_FB_Joint_PosE[6]);

					}
					else if (m_show_type == 6)
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[1].m_FB_Joint_Cmd[0],
							t.m_Out[1].m_FB_Joint_Cmd[1],
							t.m_Out[1].m_FB_Joint_Cmd[2],
							t.m_Out[1].m_FB_Joint_Cmd[3],
							t.m_Out[1].m_FB_Joint_Cmd[4],
							t.m_Out[1].m_FB_Joint_Cmd[5],
							t.m_Out[1].m_FB_Joint_Cmd[6]);

					}
					else
					{
						s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
							t.m_Out[1].m_EST_Joint_Force[0],
							t.m_Out[1].m_EST_Joint_Force[1],
							t.m_Out[1].m_EST_Joint_Force[2],
							t.m_Out[1].m_EST_Joint_Force[3],
							t.m_Out[1].m_EST_Joint_Force[4],
							t.m_Out[1].m_EST_Joint_Force[5],
							t.m_Out[1].m_EST_Joint_Force[6]);
					}

					::SendMessage(hStatusWindow, SB_SETTEXT, 3, (LPARAM)TEXT(s.GetBufferSetLength(s.GetLength() + 1)));
				}
				bool Stg = false;
				{
					unsigned char data[256];
					memset(data, 0, 256);
					long rch;
					CString sname;
					CString svalue;
					long glen;
					glen = CRobot::OnGetChDataA(data, &rch);
					while (glen != 0)
					{
						Stg = true;
						sname.Format("1#%d[", rch - 1);
						CString s = (char*)data;

						if (m_hex_tag == true)
						{
							for (long i = 0; i < glen; i++)
							{
								unsigned char c = data[i];
								unsigned char A = c / 16;
								unsigned char B = c % 16;
								char a, b;
								if (A < 10)
								{
									a = '0' + A;
								}
								else
								{
									a = 'A' + A - 10;
								}
								if (B < 10)
								{
									b = '0' + B;
								}
								else
								{
									b = 'A' + B - 10;
								}
								s += a;
								s += b;
								s += ' ';

							}
						}
						else
						{
							s = (char*)data;

						}


						sname += s;
						m_Shows[m_ShpwPos] = sname;
						m_ShpwPos++;
						if (m_ShpwPos >= 20)
						{
							m_ShpwPos = 0;
						}
						m_ShowNum++;
						if (m_ShowNum >= 20)
						{
							m_ShowNum = 20;
						}
						glen = CRobot::OnGetChDataA(data, &rch);
					}
					glen = CRobot::OnGetChDataB(data, &rch);
					while (glen != 0)
					{
						Stg = true;
						sname.Format("2#%d:[", rch - 1);
						CString s ;
						if (m_hex_tag == true)
						{
							for (long i = 0; i < glen; i++)
							{
								unsigned char c = data[i];
								unsigned char A = c / 16;
								unsigned char B = c % 16;
								char a, b;
								if (A < 10)
								{
									a = '0' + A;
								}
								else
								{
									a = 'A' + A - 10;
								}
								if (B < 10)
								{
									b = '0' + B;
								}
								else
								{
									b = 'A' + B - 10;
								}
								s += a;
								s += b;
								s += ' ';

							}
						}
						else
						{
							s = (char*)data;

						}
						sname += s;
						m_Shows[m_ShpwPos] = sname;
						m_ShpwPos++;
						if (m_ShpwPos >= 20)
						{
							m_ShpwPos = 0;
						}
						m_ShowNum++;
						if (m_ShowNum >= 20)
						{
							m_ShowNum = 20;
						}
						glen = CRobot::OnGetChDataB(data, &rch);
					}
				}
				if (Stg == true)
				{
					m_recv_2_1.Empty();
					long pos = m_ShpwPos - 1;
					CString s;
					s.Format("]%c%c",0x0d,0x0a);
					for (long i = 0; i < m_ShowNum; i++)
					{
						if (pos < 0)
						{
							pos += 20;
						}
						m_recv_2_1 += m_Shows[pos];
						m_recv_2_1 += s;
						pos--;

					}

					UpdateData(false);
				}
				
				
			}
		}
		ITT = false;
	}
	CDialogEx::OnTimer(nIDEvent);
}


void CFxStationDlg::OnBnClickedButton4()
{

	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_sq_serial;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];


	double m_sk = 10000;
	
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.SensorK", sel);
	if (CRobot::OnGetFloatPara(name, &m_sk) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}
	long m_soff = 10000;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.SensorOffset", sel);
	if (CRobot::OnGetIntPara(name, &m_soff) != 0)
	{
		AfxMessageBox("Get offset Err");
		return;
	}

	double tmp = m_soff * m_sk * 1000;
	long   ltmp = tmp;
	tmp = ltmp;
	tmp *= 0.001;
	m_sq_offset = tmp;


	DCSS t;
	if (CRobot::OnGetBuf(&t) == true)
	{
		{
			
			m_sq_offset = t.m_Out[0].m_FB_Joint_SToq[sel];
		}
	}










	UpdateData(false);

}


void CFxStationDlg::OnBnClickedButton5()
{
	// TODO: 在此添加控件通知处理程序代码


	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_sq_serial;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];


	double m_sk = 10000;

	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.SensorK", sel);
	if (CRobot::OnGetFloatPara(name, &m_sk) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}
	double m_soff = 10000;
	
	m_soff = m_sq_offset / m_sk;

	long m_soff_i = m_soff;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.SensorOffset", sel);
	if (CRobot::OnSetIntPara(name, m_soff_i) != 0)
	{
		AfxMessageBox("Set offset Err");
		return;
	}

	if (CRobot::OnSavePara() != 0)
	{
		AfxMessageBox("Set save Err");
		return;
	}


}


void CFxStationDlg::OnBnClickedButton6()
{
	// TODO: 在此添加控件通知处理程序代码

	m_show_type++;
	if (m_show_type > 7)
	{
		m_show_type = 0;
	}

	if (m_show_type == 0)
	{
		m_bt6.SetWindowTextA("位置");
	}
	if (m_show_type == 1)
	{
		m_bt6.SetWindowTextA("速度");
	}
	if (m_show_type == 2)
	{
		m_bt6.SetWindowTextA("传感器");
	}
	if (m_show_type == 3)
	{
		m_bt6.SetWindowTextA("电流");
	}
	if (m_show_type == 4)
	{
		m_bt6.SetWindowTextA("温度");
	}
	if (m_show_type == 5)
	{
		m_bt6.SetWindowTextA("外编位置");
	}
	if (m_show_type == 6)
	{
		m_bt6.SetWindowTextA("指令位置");
	}
	if (m_show_type == 7)
	{
		m_bt6.SetWindowTextA("轴外力");
	}
}


void CFxStationDlg::OnCbnSelchangeCombo1()
{
	// TODO: 在此添加控件通知处理程序代码
	
	UpdateData(true);
	int sel = m_cb1.GetCurSel();

	CString s;
	m_cb1.GetLBText(sel, s);

	m_cyc_joint_edit = s;
	UpdateData(false);
}


void CFxStationDlg::OnCbnSelchangeCombo2()
{
	// TODO: 在此添加控件通知处理程序代码
	
	UpdateData(true);
	int sel = m_cb2.GetCurSel();

	CString s;
	m_cb2.GetLBText(sel, s);

	m_cyc_joint_edit = s;
	UpdateData(false);
}


void CAboutDlg::OnCbnDblclkCombo1()
{

}


void CFxStationDlg::OnCbnDblclkCombo1()
{

	UpdateData(true);
	int sel = m_cb1.GetCurSel();

	CString s;
	m_cb1.GetLBText(sel, s);

	m_cyc_joint_edit = s;
	UpdateData(false);
}


void CFxStationDlg::OnBnClickedButton7()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}


	CRobot::OnSetIntPara("EMCY0", 0);
	CRobot::OnSetIntPara("EMCY1", 0);
	Sleep(10);
	
	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_IDLE);
	CRobot::OnSetTargetState_B(ARM_STATE_IDLE);

	CRobot::OnSetSend();
	
}


void CFxStationDlg::OnBnClickedButtonWorkCycfile1()
{
	// TODO: 在此添加控件通知处理程序代码	
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_pset_a1p50_tag != -1)
	{
		return;
	}

	m_pset_a1p50_tag = 0;
}


void CFxStationDlg::OnBnClickedButton8()
{
	// TODO: 在此添加控件通知处理程序代码
	long targetID[35];
	targetID[0] = 0;
	targetID[1] = 1;
	targetID[2] = 2;
	targetID[3] = 3;
	targetID[4] = 4;
	targetID[5] = 5;
	targetID[6] = 6;
	CRobot::OnStartGather(7, targetID, 100000);
}


void CFxStationDlg::OnBnClickedButton9()
{
	// TODO: 在此添加控件通知处理程序代码
	if (CRobot::OnSaveGatherData((char*)"D:\\TMP\\station_gather.tmp") == true)
	{
		AfxMessageBox("Done");
	}
	else
	{
		AfxMessageBox("Save D:\\TMP\\station_gather.tmp Err");
	}
}


void CFxStationDlg::OnBnClickedButtonRunCKd2()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_B(ARM_STATE_TORQ);
	CRobot::OnSetImpType_B(2);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonRunJKd2()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_B(ARM_STATE_TORQ);
	CRobot::OnSetImpType_B(1);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonRunCKd1()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_TORQ);
	CRobot::OnSetImpType_A(2);

	CRobot::OnSetSend();

	in_dg_tag_1 = false;
}


void CFxStationDlg::OnBnClickedButtonRunPvt2()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_B(ARM_STATE_PVT);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonRunJointTrace2()
{
	// TODO: 在此添加控件通知处理程序代码

	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_B(ARM_STATE_POSITION);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnEnChangeEdit6()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CFxStationDlg::OnBnClickedButtonWorkJoint2()
{

	if (m_LinkTag == false)
	{
		return;
	}

	OnGetLmt();
	UpdateData(true);
	int sel = m_cb2.GetCurSel();

	CString s;
	m_cb2.GetLBText(sel, s);


	char* buf = s.GetBufferSetLength(s.GetLength() + 3);

	double sencv[100];
	long num = 10;
	if (OnGetValue(buf, sencv, num) == true)
	{
		if (num != 7)
		{
			AfxMessageBox("NEED 7 VALUE");
			return;
		}

		for (long i = 0; i < 7; i++)
		{
			if (sencv[i] < (m_RunLmt[1].m_pos_l[i] + 1.5))
			{
				CString s;
				s.Format("轴%d下限位 %lf（含边界）", i + 1, m_RunLmt[1].m_pos_l[i] + 1.5);
				AfxMessageBox(s);
				return;
			}
			if (sencv[i] > (m_RunLmt[1].m_pos_u[i] + 1.5))
			{
				CString s;
				s.Format("轴%d上限位 %lf（含边界）", i + 1, m_RunLmt[1].m_pos_u[i] - 1.5);
				AfxMessageBox(s);
				return;
			}
		}


		CRobot::OnClearSet();
		CRobot::OnSetJointCmdPos_B(sencv);
		CRobot::OnSetSend();




	}
}


void CFxStationDlg::OnBnClickedButton10()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	double dir[6];
	dir[0] = 1;
	dir[1] = 0;
	dir[2] = 0;
	dir[3] = 0;
	dir[4] = 0;
	dir[5] = 0;


	double fpara[7];

	fpara[0] = 0;
	fpara[1] = 0;
	fpara[2] = 0;
	fpara[3] = 0;
	fpara[4] = 0;
	fpara[5] = 0;
	fpara[6] = 0;

	CRobot::OnSetForceCtrPara_A(0, dir, fpara, m_ForceLmt);

	CRobot::OnSetForceCmd_A(m_Force);

	CRobot::OnSetImpType_A(3);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton11()
{
	// TODO: 在此添加控件通知处理程序代码

	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	double dir[6];
	dir[0] = 0;
	dir[1] = 1;
	dir[2] = 0;
	dir[3] = 0;
	dir[4] = 0;
	dir[5] = 0;


	double fpara[7];

	fpara[0] = 0;
	fpara[1] = 0;
	fpara[2] = 0;
	fpara[3] = 0;
	fpara[4] = 0;
	fpara[5] = 0;
	fpara[6] = 0;
	CRobot::OnClearSet();
	CRobot::OnSetForceCtrPara_A(0, dir, fpara, m_ForceLmt);

	CRobot::OnSetForceCmd_A(m_Force);

	CRobot::OnSetImpType_A(3);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton12()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	double dir[6];
	dir[0] = 0;
	dir[1] = 0;
	dir[2] = 1;
	dir[3] = 0;
	dir[4] = 0;
	dir[5] = 0;


	double fpara[7];

	fpara[0] = 0;
	fpara[1] = 0;
	fpara[2] = 0;
	fpara[3] = 0;
	fpara[4] = 0;
	fpara[5] = 0;
	fpara[6] = 0;
	CRobot::OnClearSet();
	CRobot::OnSetForceCtrPara_A(0, dir, fpara, m_ForceLmt);

	CRobot::OnSetForceCmd_A(m_Force);

	CRobot::OnSetImpType_A(3);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton13()
{

}


void CFxStationDlg::OnBnClickedButtonRunFctrl1()
{
	// TODO: 在此添加控件通知处理程序代码
	char name[30];
	memset(name, 0, 30);

	long err[7];
	for (long i = 0; i < 7; i++)
	{
		sprintf(name, "SERVO0ERR%d",i);
		CRobot::OnGetIntPara(name, &err[i]);
	}
	
	CString s;
	s.Format("0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,",
		err[0], err[1], err[2], err[3], err[4], err[5], err[6]);

	AfxMessageBox(s);

}


void CFxStationDlg::OnBnClickedButton14()
{
	if (m_LinkTag == true)
	{
		DCSS t;
		if (CRobot::OnGetBuf(&t) == true)
		{
			CString s;
			
				s.Format("%.5lf %.5lf %.5lf %.5lf %.5lf %.5lf %.5lf ",
					t.m_Out[0].m_FB_Joint_Pos[0],
					t.m_Out[0].m_FB_Joint_Pos[1],
					t.m_Out[0].m_FB_Joint_Pos[2],
					t.m_Out[0].m_FB_Joint_Pos[3],
					t.m_Out[0].m_FB_Joint_Pos[4],
					t.m_Out[0].m_FB_Joint_Pos[5],
					t.m_Out[0].m_FB_Joint_Pos[6]);
			m_cyc_joint_edit = s;
			UpdateData(false);
		}
	}
}


void CFxStationDlg::OnBnClickedButton15()
{
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_EncSel;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];

	long res;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.EncRes", sel);
	if (CRobot::OnGetIntPara(name, &res) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}


	double  ratio1;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.Ratio1", sel);
	if (CRobot::OnGetFloatPara(name, &ratio1) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double  ratio2;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.Ratio2", sel);
	if (CRobot::OnGetFloatPara(name, &ratio2) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}

	long EncOffset;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.EncOffset", sel);
	if (CRobot::OnGetIntPara(name, &EncOffset) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double dres = res;
	
	double tmp1 = dres / (ratio1  / ratio2);

	double curoff = EncOffset;

	long tmp2 = 1000 * (ratio2 * (curoff / dres ) / ratio1);
	m_Encoffset = tmp2;
	m_Encoffset *= 0.001;

	UpdateData(false);
}


void CFxStationDlg::OnEnChangeEdit11()
{

}


void CFxStationDlg::OnBnClickedButton16()
{
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_EncSel;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];

	long res;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.EncRes", sel);
	if (CRobot::OnGetIntPara(name, &res) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}


	double  ratio1;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.Ratio1", sel);
	if (CRobot::OnGetFloatPara(name, &ratio1) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double  ratio2;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.Ratio2", sel);
	if (CRobot::OnGetFloatPara(name, &ratio2) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}

	long EncOffset;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.EncOffset", sel);
	if (CRobot::OnGetIntPara(name, &EncOffset) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double dres = res;

	double tmp1 = dres / (ratio1 / ratio2);

	double curoff = EncOffset;


	double pl = (m_Encoffset * ratio1 / ratio2) * dres;

	curoff += pl;



	long m_soff_i = curoff;
	memset(name, 0, 30);
	sprintf(name, "R.A0.L%d.BASIC.EncOffset", sel);
	if (CRobot::OnSetIntPara(name, m_soff_i) != 0)
	{
		AfxMessageBox("Set offset Err");
		return;
	}

	if (CRobot::OnSavePara() != 0)
	{
		AfxMessageBox("Set save Err");
		return;
	}




	UpdateData(false);
}


void CFxStationDlg::OnBnClickedButton17()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_sq_serial;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];


	double m_sk = 10000;

	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.SensorK", sel);
	if (CRobot::OnGetFloatPara(name, &m_sk) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}
	long m_soff = 10000;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.SensorOffset", sel);
	if (CRobot::OnGetIntPara(name, &m_soff) != 0)
	{
		AfxMessageBox("Get offset Err");
		return;
	}

	double tmp = m_soff * m_sk * 1000;
	long   ltmp = tmp;
	tmp = ltmp;
	tmp *= 0.001;
	m_sq_offset = tmp;


	DCSS t;
	if (CRobot::OnGetBuf(&t) == true)
	{
		{

			m_sq_offset = t.m_Out[1].m_FB_Joint_SToq[sel];
		}
	}

	UpdateData(false);
}


void CFxStationDlg::OnBnClickedButton18()
{
	// TODO: 在此添加控件通知处理程序代码


	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_sq_serial;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];


	double m_sk = 10000;

	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.SensorK", sel);
	if (CRobot::OnGetFloatPara(name, &m_sk) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}
	double m_soff = 10000;

	m_soff = m_sq_offset / m_sk;

	long m_soff_i = m_soff;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.SensorOffset", sel);
	if (CRobot::OnSetIntPara(name, m_soff_i) != 0)
	{
		AfxMessageBox("Set offset Err");
		return;
	}

	if (CRobot::OnSavePara() != 0)
	{
		AfxMessageBox("Set save Err");
		return;
	}

}


void CFxStationDlg::OnBnClickedButton19()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_EncSel;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];

	long res;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.EncRes", sel);
	if (CRobot::OnGetIntPara(name, &res) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}


	double  ratio1;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.Ratio1", sel);
	if (CRobot::OnGetFloatPara(name, &ratio1) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double  ratio2;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.Ratio2", sel);
	if (CRobot::OnGetFloatPara(name, &ratio2) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}

	long EncOffset;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.EncOffset", sel);
	if (CRobot::OnGetIntPara(name, &EncOffset) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double dres = res;

	double tmp1 = dres / (ratio1 / ratio2);

	double curoff = EncOffset;

	long tmp2 = 1000 * (ratio2 * (curoff / dres) / ratio1);
	m_Encoffset = tmp2;
	m_Encoffset *= 0.001;

	UpdateData(false);
}


void CFxStationDlg::OnBnClickedButton20()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	int sel = m_EncSel;
	if (sel < 0 || sel >= 7)
	{
		return;
	}

	char name[30];

	long res;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.EncRes", sel);
	if (CRobot::OnGetIntPara(name, &res) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}


	double  ratio1;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.Ratio1", sel);
	if (CRobot::OnGetFloatPara(name, &ratio1) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double  ratio2;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.Ratio2", sel);
	if (CRobot::OnGetFloatPara(name, &ratio2) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}

	long EncOffset;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.EncOffset", sel);
	if (CRobot::OnGetIntPara(name, &EncOffset) != 0)
	{
		AfxMessageBox("Get K Err");
		return;
	}



	double dres = res;

	double tmp1 = dres / (ratio1 / ratio2);

	double curoff = EncOffset;


	double pl = (m_Encoffset * ratio1 / ratio2) * dres;

	curoff += pl;



	long m_soff_i = curoff;
	memset(name, 0, 30);
	sprintf(name, "R.A1.L%d.BASIC.EncOffset", sel);
	if (CRobot::OnSetIntPara(name, m_soff_i) != 0)
	{
		AfxMessageBox("Set offset Err");
		return;
	}

	if (CRobot::OnSavePara() != 0)
	{
		AfxMessageBox("Set save Err");
		return;
	}




	UpdateData(false);
}


void CFxStationDlg::OnEnChangeEdit5()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CFxStationDlg::OnBnClickedButton21()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == true)
	{
		DCSS t;
		if (CRobot::OnGetBuf(&t) == true)
		{
			CString s;

			s.Format("%.3lf %.3lf %.3lf %.3lf %.3lf %.3lf %.3lf ",
				t.m_Out[1].m_FB_Joint_Pos[0],
				t.m_Out[1].m_FB_Joint_Pos[1],
				t.m_Out[1].m_FB_Joint_Pos[2],
				t.m_Out[1].m_FB_Joint_Pos[3],
				t.m_Out[1].m_FB_Joint_Pos[4],
				t.m_Out[1].m_FB_Joint_Pos[5],
				t.m_Out[1].m_FB_Joint_Pos[6]);
			m_cyc_joint_edit = s;
			UpdateData(false);
		}
	}
}


void CFxStationDlg::OnBnClickedButton22()
{
	long vers;
	long type1;
	long type2;
	long uemg;
	long p1;
	long p2;

	double GravityX1;
	double GravityY1;
	double GravityZ1;
	double GravityX2;
	double GravityY2;
	double GravityZ2;


	long  dftag1;
	long  dftag2;

	double dfseta1;
	double dfsetb1;
	double dfsetc1;
	double dfseta2;
	double dfsetb2;
	double dfsetc2;
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "VERSION");
		CRobot::OnGetIntPara(name, &vers);
	}

	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.Type");
		CRobot::OnGetIntPara(name, &type1);
	}

	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.Type");
		CRobot::OnGetIntPara(name, &type2);
	}


	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.TerminalPolar");
		CRobot::OnGetIntPara(name, &p1);
	}

	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.TerminalPolar");
		CRobot::OnGetIntPara(name, &p2);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.GravityX");
		CRobot::OnGetFloatPara(name, &GravityX1);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.GravityY");
		CRobot::OnGetFloatPara(name, &GravityY1);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.GravityZ");
		CRobot::OnGetFloatPara(name, &GravityZ1);
	}


	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.GravityX");
		CRobot::OnGetFloatPara(name, &GravityX2);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.GravityY");
		CRobot::OnGetFloatPara(name, &GravityY2);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.GravityZ");
		CRobot::OnGetFloatPara(name, &GravityZ2);
	}

	uemg = -1;
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.BASIC.UseEMG");
		CRobot::OnGetIntPara(name, &uemg);
	}


	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.DynFloatTag");
		CRobot::OnGetIntPara(name, &dftag1);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.DynFloatTag");
		CRobot::OnGetIntPara(name, &dftag2);
	}

	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.GYROSETA");
		CRobot::OnGetFloatPara(name, &dfseta1);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.GYROSETB");
		CRobot::OnGetFloatPara(name, &dfsetb1);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.BASIC.GYROSETC");
		CRobot::OnGetFloatPara(name, &dfsetc1);
	}


	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.GYROSETA");
		CRobot::OnGetFloatPara(name, &dfseta2);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.GYROSETB");
		CRobot::OnGetFloatPara(name, &dfsetb2);
	}
	{
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.BASIC.GYROSETC");
		CRobot::OnGetFloatPara(name, &dfsetc2);
	}



	CString st;
	if (uemg == 0)
	{
		st.Format("DISABLE EMG DEV");
	}
	else if(uemg == 1)
	{
		st.Format("ENABLE EMG DEV");
	}
	else
	{
		st.Format("EMG DEV UNDEFINE");
	}
	

	CString s0;
	CString s1;
	if (type1 == 1007)
	{
		s0.Format("ARM1: SRS  TerminalPolar %d GRV<%.3lf,%.3lf,%.3lf> DF %d<A%.3lf,B%.3lf,C%.3lf>",p1, GravityX1, GravityY1, GravityZ1,dftag1,dfseta1, dfsetb1, dfsetc1);
	}
	else if(type1 == 1017)
	{
		s0.Format("ARM1: CCS  TerminalPolar %d GRV<%.3lf,%.3lf,%.3lf> DF %d<A%.3lf,B%.3lf,C%.3lf>", p1, GravityX1, GravityY1, GravityZ1, dftag1, dfseta1, dfsetb1, dfsetc1);
	}
	else
	{
		s0.Format("ARM1: None");
	}


	if (type2 == 1007)
	{
		s1.Format("ARM2: SRS  TerminalPolar %d GRV<%.3lf,%.3lf,%.3lf>DF %d<A%.3lf,B%.3lf,C%.3lf>", p2, GravityX2, GravityY2, GravityZ2, dftag2, dfseta2, dfsetb2, dfsetc2);
	}
	else if (type2 == 1017)
	{
		s1.Format("ARM2: CCS  TerminalPolar %d GRV<%.3lf,%.3lf,%.3lf>DF %d<A%.3lf,B%.3lf,C%.3lf>", p2, GravityX2, GravityY2, GravityZ2, dftag2, dfseta2, dfsetb2, dfsetc2);
	}
	else
	{
		s1.Format("ARM2: None");
	}
	CString s;
	s.Format("VER:%d	%c%c",vers,0x0d,0x0a);
	CString s3;
	s3.Format("%c%c",0x0d,0x0a);
	s += st;
	s += s3;
	s += s0;
	s += s3;
	s += s1;

	AfxMessageBox(s);
}


void CFxStationDlg::OnBnClickedButton24()
{
	if (CRobot::OnStopGather() == true)
	{
		AfxMessageBox("Done");
	}
}


void CFxStationDlg::OnBnClickedButton23()
{
	// TODO: 在此添加控件通知处理程序代码
	CPointSet pset;
	if (pset.OnLoadFast((char*)"D:\\TMP\\station_gather.tmp") == false)
	{
		AfxMessageBox("Load D:\\TMP\\station_gather.tmp Err");
		return;
	}

	long num = pset.OnGetPointNum();

	CPointSet pset2;
	pset2.OnInit(PotT_9d);

	double v[9];

	for (long i = 0; i < num; i+= 20)
	{
		double* pv = pset.OnGetPoint(i);
		v[0] = pv[2];
		v[1] = pv[3];
		v[2] = pv[4];
		v[3] = pv[5];
		v[4] = pv[6];
		v[5] = pv[7];
		v[6] = pv[8];
		v[7] = 0;
		v[8] = 0;
		pset2.OnSetPoint(v);
	}
	if (pset2.OnSave((char*)"D:\\TMP\\A1.R1P50") == false)
	{
		AfxMessageBox("Save A1.R1P50 ERR");
		return;
	}

	AfxMessageBox("Save D:\\TMP\\A1.R1P50");
	


}


void CFxStationDlg::OnBnClickedButton25()
{
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);

	OnGetLmt();
	CString s = m_cyc_joint_edit;
	char* buf = s.GetBufferSetLength(s.GetLength() + 3);

	double sencv[100];
	long num = 10;
	if (OnGetValue(buf, sencv, num) == true)
	{
		
		if (num != 7)
		{
			return;
		}
		
		for (long i = 0; i < 7; i++)
		{
			if (sencv[i] < (m_RunLmt[0].m_pos_l[i] + 1.5))
			{
				CString s;
				s.Format("轴%d下限位 %lf（含边界）", i + 1, m_RunLmt[0].m_pos_l[i] + 1.5);
				AfxMessageBox(s);
				return;
			}
			if (sencv[i] > (m_RunLmt[0].m_pos_u[i] + 1.5))
			{
				CString s;
				s.Format("轴%d上限位 %lf（含边界）", i + 1, m_RunLmt[0].m_pos_u[i] - 1.5);
				AfxMessageBox(s);
				return;
			}
		}
		

		CRobot::OnClearSet();
		CRobot::OnSetJointCmdPos_A(sencv);
		CRobot::OnSetSend();
	}
	else
	{
		AfxMessageBox("ERR FORMAT");
	}
}


void CFxStationDlg::OnBnClickedButton26()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	double dir[6];
	dir[0] = 1;
	dir[1] = 0;
	dir[2] = 0;
	dir[3] = 0;
	dir[4] = 0;
	dir[5] = 0;


	double fpara[7];

	fpara[0] = 0;
	fpara[1] = 0;
	fpara[2] = 0;
	fpara[3] = 0;
	fpara[4] = 0;
	fpara[5] = 0;
	fpara[6] = 0;

	CRobot::OnSetForceCtrPara_B(0, dir, fpara, m_ForceLmt);

	CRobot::OnSetForceCmd_B(m_Force);

	CRobot::OnSetImpType_B(3);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton27()
{

	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	double dir[6];
	dir[0] = 0;
	dir[1] = 1;
	dir[2] = 0;
	dir[3] = 0;
	dir[4] = 0;
	dir[5] = 0;


	double fpara[7];

	fpara[0] = 0;
	fpara[1] = 0;
	fpara[2] = 0;
	fpara[3] = 0;
	fpara[4] = 0;
	fpara[5] = 0;
	fpara[6] = 0;
	CRobot::OnClearSet();
	CRobot::OnSetForceCtrPara_B(0, dir, fpara, m_ForceLmt);

	CRobot::OnSetForceCmd_B(m_Force);

	CRobot::OnSetImpType_B(3);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton28()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	double dir[6];
	dir[0] = 0;
	dir[1] = 0;
	dir[2] = 1;
	dir[3] = 0;
	dir[4] = 0;
	dir[5] = 0;


	double fpara[7];

	fpara[0] = 0;
	fpara[1] = 0;
	fpara[2] = 0;
	fpara[3] = 0;
	fpara[4] = 0;
	fpara[5] = 0;
	fpara[6] = 0;
	CRobot::OnClearSet();
	CRobot::OnSetForceCtrPara_B(0, dir, fpara, m_ForceLmt);

	CRobot::OnSetForceCmd_B(m_Force);

	CRobot::OnSetImpType_B(3);

	CRobot::OnSetSend();

}


void CFxStationDlg::OnBnClickedButton29()
{
	long targetID[35];
	targetID[0] = 0;
	targetID[1] = 1;
	targetID[2] = 2;
	targetID[3] = 3;
	targetID[4] = 4;
	targetID[5] = 5;
	targetID[6] = 6;


	targetID[7] = 10;
	targetID[8] = 11;
	targetID[9] = 12;
	targetID[10] = 13;
	targetID[11] = 14;
	targetID[12] = 15;
	targetID[13] = 16;


	targetID[14] = 50;
	targetID[15] = 51;
	targetID[16] = 52;
	targetID[17] = 53;
	targetID[18] = 54;
	targetID[19] = 55;
	targetID[20] = 56;

	targetID[21] = 76;

	CRobot::OnStartGather(22, targetID, 200000);
}


void CFxStationDlg::OnBnClickedButton30()
{
	CPointSet pset;
	if (pset.OnLoadFast((char*)"D:\\TMP\\station_gather.tmp") == false)
	{
		AfxMessageBox("Load D:\\TMP\\station_gather.tmp Err");
		return;
	}

	long num = pset.OnGetPointNum();

	CPointSet pset2;
	pset2.OnInit(PotT_29d);

	double v[29];

	for (long i = 0; i < num; i ++)
	{
		double* pv = pset.OnGetPoint(i);

		long j;

		v[0] = pv[23];
		for ( j = 0; j < 7; j++)
		{
			v[1+j] = pv[2+j];
			v[8 + j] = 0;
			v[15 + j] = pv[2 + 7 + 7 + j];
			v[22 + j] = pv[2 + 7 + j];
		}
		
		
		pset2.OnSetPoint(v);
	}
	if (pset2.OnSaveRaw((char*)"D:\\TMP\\A1.dyncalf") == false)
	{
		AfxMessageBox("Save A1.dyncalf ERR");
		return;
	}

	AfxMessageBox("Save D:\\TMP\\A1.dyncalf");
}


void CFxStationDlg::OnBnClickedButton31()
{
	if (m_LinkTag == false)
	{
		AfxMessageBox("no link");
		return;
	}
	CFileDialog fd(true, NULL, NULL, 0, ".DCLB_S|*.DCLB_S");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();


	CPointSet pset;

	if (pset.OnLoadXFile(s.GetBufferSetLength(s.GetLength() + 1),10,10) == false)
	{
		AfxMessageBox("DCLB_S ERR");
		return;
	}

	long num = pset.OnGetPointNum();
	if (num != 7)
	{

		AfxMessageBox("DCLB_S file ERR");
		return;
	}

	double m  ,     mx  ,    my  ,    mz  ,    ixx  ,   ixy ,    ixz,     iyy ,    iyz ,    izz;
	for (long i = 0; i < 7; i++)
	{
		double* p = pset.OnGetPoint(i);
		m = p[0];
		mx = p[1];
		my = p[2];
		mz = p[3];
		ixx = p[4];
		ixy = p[5];
		ixz = p[6];
		iyy = p[7];
		iyz = p[8];
		izz = p[9];

		char name[30];


		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.M", i);
		if (CRobot::OnSetFloatPara(name, m) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.MRX", i);
		if (CRobot::OnSetFloatPara(name, mx) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.MRY", i);
		if (CRobot::OnSetFloatPara(name, my) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.MRZ", i);
		if (CRobot::OnSetFloatPara(name, mz) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.InertiaXX", i);
		if (CRobot::OnSetFloatPara(name, ixx) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.InertiaXY", i);
		if (CRobot::OnSetFloatPara(name, ixy) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.InertiaXZ", i);
		if (CRobot::OnSetFloatPara(name, ixz) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.InertiaYY", i);
		if (CRobot::OnSetFloatPara(name, iyy) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.InertiaYZ", i);
		if (CRobot::OnSetFloatPara(name, iyz) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DYNAMIC.InertiaZZ", i);
		if (CRobot::OnSetFloatPara(name, izz) < 0)
		{
			AfxMessageBox(name);
			return;
		}

	}


	CRobot::OnSavePara();


	AfxMessageBox("done");
	 
}


void CFxStationDlg::OnBnClickedButtonSetjkd2()
{
	if (m_LinkTag == false)
	{
		return;
	}

	
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_A(1);
	CRobot::OnSetSend();
	
}


void CFxStationDlg::OnBnClickedButton32()
{
	if (m_LinkTag == false)
	{
		AfxMessageBox("no link");
		return;
	}
	CFileDialog fd(true, NULL, NULL, 0, ".DCLB_S|*.DCLB_S");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();


	CPointSet pset;

	if (pset.OnLoadXFile(s.GetBufferSetLength(s.GetLength() + 1), 10, 10) == false)
	{
		AfxMessageBox("DCLB_S ERR");
		return;
	}

	long num = pset.OnGetPointNum();
	if (num != 7)
	{

		AfxMessageBox("DCLB_S file ERR");
		return;
	}

	double m, mx, my, mz, ixx, ixy, ixz, iyy, iyz, izz;
	for (long i = 0; i < 7; i++)
	{
		double* p = pset.OnGetPoint(i);
		m = p[0];
		mx = p[1];
		my = p[2];
		mz = p[3];
		ixx = p[4];
		ixy = p[5];
		ixz = p[6];
		iyy = p[7];
		iyz = p[8];
		izz = p[9];

		char name[30];


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.M", i);
		if (CRobot::OnSetFloatPara(name, m) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.MRX", i);
		if (CRobot::OnSetFloatPara(name, mx) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.MRY", i);
		if (CRobot::OnSetFloatPara(name, my) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.MRZ", i);
		if (CRobot::OnSetFloatPara(name, mz) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.InertiaXX", i);
		if (CRobot::OnSetFloatPara(name, ixx) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.InertiaXY", i);
		if (CRobot::OnSetFloatPara(name, ixy) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.InertiaXZ", i);
		if (CRobot::OnSetFloatPara(name, ixz) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.InertiaYY", i);
		if (CRobot::OnSetFloatPara(name, iyy) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.InertiaYZ", i);
		if (CRobot::OnSetFloatPara(name, iyz) < 0)
		{
			AfxMessageBox(name);
			return;
		}


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DYNAMIC.InertiaZZ", i);
		if (CRobot::OnSetFloatPara(name, izz) < 0)
		{
			AfxMessageBox(name);
			return;
		}

	}


	CRobot::OnSavePara();


	AfxMessageBox("done");
}


void CFxStationDlg::OnBnClickedButton33()
{
	// TODO: 在此添加控件通知处理程序代码


	if (m_LinkTag == false)
	{
		AfxMessageBox("no link");
		return;
	}
	CFileDialog fd(true, NULL, NULL, 0, ".KINEP|*.KINEP");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();


	CPointSet pset;

	if (pset.OnLoadXFile(s.GetBufferSetLength(s.GetLength() + 1), 4, 4) == false)
	{
		AfxMessageBox("KINEP ERR");
		return;
	}

	long num = pset.OnGetPointNum();
	if (num != 8)
	{

		AfxMessageBox("KINEP file ERR");
		return;
	}

	double alpha, a, d, theta;
	for (long i = 0; i < 7; i++)
	{
		double* p = pset.OnGetPoint(i);
		alpha = p[0];
		a = p[1];
		d = p[2];
		theta = p[3];

		char name[30];


		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DH.Alpha", i);
		if (CRobot::OnSetFloatPara(name, alpha) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DH.A", i);
		if (CRobot::OnSetFloatPara(name, a) < 0)
		{
			AfxMessageBox(name);
			return;
		}



		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DH.D", i);
		if (CRobot::OnSetFloatPara(name, d) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A0.L%d.DH.Theta", i);
		if (CRobot::OnSetFloatPara(name, theta) < 0)
		{
			AfxMessageBox(name);
			return;
		}
	}
	{
		double* p = pset.OnGetPoint(7);
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A0.FLANGE.Alpha");
		if (CRobot::OnSetFloatPara(name, p[0]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A0.FLANGE.A");
		if (CRobot::OnSetFloatPara(name, p[1]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A0.FLANGE.D");
		if (CRobot::OnSetFloatPara(name, p[2]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A0.FLANGE.Theta");
		if (CRobot::OnSetFloatPara(name, p[3]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
	}

	CRobot::OnSavePara();


	AfxMessageBox("done");

}


void CFxStationDlg::OnBnClickedButton34()
{

	if (m_LinkTag == false)
	{
		AfxMessageBox("no link");
		return;
	}
	CFileDialog fd(true, NULL, NULL, 0, ".KINEP|*.KINEP");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();


	CPointSet pset;

	if (pset.OnLoadXFile(s.GetBufferSetLength(s.GetLength() + 1), 4, 4) == false)
	{
		AfxMessageBox("KINEP ERR");
		return;
	}

	long num = pset.OnGetPointNum();
	if (num != 8)
	{

		AfxMessageBox("KINEP file ERR");
		return;
	}

	double alpha, a, d, theta;
	for (long i = 0; i < 7; i++)
	{
		double* p = pset.OnGetPoint(i);
		alpha = p[0];
		a = p[1];
		d = p[2];
		theta = p[3];

		char name[30];


		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DH.Alpha", i);
		if (CRobot::OnSetFloatPara(name, alpha) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DH.A", i);
		if (CRobot::OnSetFloatPara(name, a) < 0)
		{
			AfxMessageBox(name);
			return;
		}



		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DH.D", i);
		if (CRobot::OnSetFloatPara(name, d) < 0)
		{
			AfxMessageBox(name);
			return;
		}

		memset(name, 0, 30);
		sprintf(name, "R.A1.L%d.DH.Theta", i);
		if (CRobot::OnSetFloatPara(name, theta) < 0)
		{
			AfxMessageBox(name);
			return;
		}
	}

	{
		double* p = pset.OnGetPoint(7);
		char name[30];
		memset(name, 0, 30);
		sprintf(name, "R.A1.FLANGE.Alpha");
		if (CRobot::OnSetFloatPara(name, p[0]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A1.FLANGE.A");
		if (CRobot::OnSetFloatPara(name, p[1]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A1.FLANGE.D");
		if (CRobot::OnSetFloatPara(name, p[2]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
		memset(name, 0, 30);
		sprintf(name, "R.A1.FLANGE.Theta");
		if (CRobot::OnSetFloatPara(name, p[3]) < 0)
		{
			AfxMessageBox(name);
			return;
		}
	}

	CRobot::OnSavePara();

	AfxMessageBox("done");
}


void CFxStationDlg::OnBnClickedButton35()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	UpdateData(true);
	OnGetLmt();
	CString s = m_cyc_joint_edit;
	char* buf = s.GetBufferSetLength(s.GetLength() + 3);

	double sencv[100];
	long num = 10;
	if (OnGetValue(buf, sencv, num) == true)
	{

		if (num != 7)
		{
			return;
		}
		for (long i = 0; i < 7; i++)
		{
			if (sencv[i] < (m_RunLmt[1].m_pos_l[i] + 1.5))
			{
				CString s;
				s.Format("轴%d下限位 %lf（含边界）", i + 1, m_RunLmt[1].m_pos_l[i] + 1.5);
				AfxMessageBox(s);
				return;
			}
			if (sencv[i] > (m_RunLmt[1].m_pos_u[i] + 1.5))
			{
				CString s;
				s.Format("轴%d上限位 %lf（含边界）", i + 1, m_RunLmt[1].m_pos_u[i] - 1.5);
				AfxMessageBox(s);
				return;
			}
		}
		CRobot::OnClearSet();
		CRobot::OnSetJointCmdPos_B(sencv);
		CRobot::OnSetSend();
	}
	else
	{
		AfxMessageBox("ERR FORMAT");
	}
}


void CFxStationDlg::OnBnClickedButton36()
{
	// TODO: 在此添加控件通知处理程序代码

	long targetID[35];
	targetID[0] = 100;
	targetID[1] = 101;
	targetID[2] = 102;
	targetID[3] = 103;
	targetID[4] = 104;
	targetID[5] = 105;
	targetID[6] = 106;


	targetID[7] =	110;
	targetID[8] =	111;
	targetID[9] =	112;
	targetID[10] =	113;
	targetID[11] =	114;
	targetID[12] =	115;
	targetID[13] =	116;


	targetID[14] = 150;
	targetID[15] = 151;
	targetID[16] = 152;
	targetID[17] = 153;
	targetID[18] = 154;
	targetID[19] = 155;
	targetID[20] = 156;

	targetID[21] = 176;

	CRobot::OnStartGather(22, targetID, 200000);
}


void CFxStationDlg::OnEnChangeEditToolM()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CFxStationDlg::OnEnChangeEditToolMcpx()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CFxStationDlg::OnEnChangeEdit3()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CFxStationDlg::OnBnClickedButton37()
{
	char name[30];
	memset(name, 0, 30);
	sprintf(name, "RESET0");
	CRobot::OnSetIntPara(name, 0);

	in_dg_tag_1 = false;
	
}


void CFxStationDlg::OnBnClickedButton38()
{
	// TODO: 在此添加控件通知处理程序代码
	char name[30];
	memset(name, 0, 30);
	sprintf(name, "RESET1");
	CRobot::OnSetIntPara(name, 1);
}


void CFxStationDlg::OnBnClickedButton39()
{
	// TODO: 在此添加控件通知处理程序代码



}


void CFxStationDlg::OnBnClickedButton40()
{
	// TODO: 在此添加控件通知处理程序代码

}


void CFxStationDlg::OnBnClickedButtonSetjkd3()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_A(2);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd4()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_A(3);
	CRobot::OnSetSend();
	
}


void CFxStationDlg::OnBnClickedButtonSetjkd5()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_A(4);
	CRobot::OnSetSend();
	
}


void CFxStationDlg::OnBnClickedButtonSetjkd6()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_A(5);
	CRobot::OnSetSend();
	
}


void CFxStationDlg::OnBnClickedButtonSetjkd7()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_A(0);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd8()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_B(1);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd9()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_B(2);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd10()
{
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_B(3);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd11()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_B(4);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd12()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_B(5);
	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButtonSetjkd13()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}

	UpdateData(true);
	CRobot::OnClearSet();
	CRobot::OnSetDragSpace_B(0);
	CRobot::OnSetSend();
	in_dg_tag_1 = false;
}


void CFxStationDlg::OnBnClickedUpdatesystembtn()
{
	// TODO: 在此添加控件通知处理程序代码
	CFileDialog fd(true, NULL, NULL, 0, ".tar|*.tar");

	if (fd.DoModal() != IDOK)
	{
		return ;
	}

	CString s = fd.GetPathName();
	CRobot::OnUpdateSystem(s.GetBufferSetLength(s.GetLength()+1));
}

void CFxStationDlg::OnBnClickedDownloadlogbtn()
{
	CFileDialog fd(false, NULL, NULL, 0, ".txt|*.txt");

	if (fd.DoModal() != IDOK)
	{
		return ;
	}

	CString s = fd.GetPathName();
	if (s.Find(".txt") == -1)
	{
		s += ".txt";
	}

	CRobot::OnDownloadLog(s.GetBufferSetLength(s.GetLength() + 1));
}


void CFxStationDlg::OnBnClickedButtonRunFctrl2()
{
	char name[30];
	memset(name, 0, 30);

	long err[7];
	for (long i = 0; i < 7; i++)
	{
		sprintf(name, "SERVO1ERR%d", i);
		CRobot::OnGetIntPara(name, &err[i]);
	}

	CString s;
	s.Format("0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,0x%04x,",
		err[0], err[1], err[2], err[3], err[4], err[5], err[6]);

	AfxMessageBox(s);
}


void CFxStationDlg::OnBnClickedButton42()
{
	CPointSet pset;
	if (pset.OnLoadFast((char*)"D:\\TMP\\station_gather.tmp") == false)
	{
		AfxMessageBox("Load D:\\TMP\\station_gather.tmp Err");
		return;
	}

	long num = pset.OnGetPointNum();

	CPointSet pset2;
	pset2.OnInit(PotT_9d);

	double v[9];

	for (long i = 0; i < num; i += 20)
	{
		double* pv = pset.OnGetPoint(i);
		v[0] = pv[2];
		v[1] = pv[3];
		v[2] = pv[4];
		v[3] = pv[5];
		v[4] = pv[6];
		v[5] = pv[7];
		v[6] = pv[8];
		v[7] = 0;
		v[8] = 0;
		pset2.OnSetPoint(v);
	}
	if (pset2.OnSave((char*)"D:\\TMP\\A1.R2P50") == false)
	{
		AfxMessageBox("Save A1.R1P50 ERR");
		return;
	}

	AfxMessageBox("Save D:\\TMP\\A1.R2P50");
}


void CFxStationDlg::OnBnClickedButtonWorkCycfile2()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_pset_a2p50_tag != -1)
	{
		return;
	}

	m_pset_a2p50_tag = 0;
}


void CFxStationDlg::OnBnClickedButtonWorkCycfile()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_pset_a1p50_tag != -1)
	{
		return;
	}
	if (m_pset_a2p50_tag != -1)
	{
		return;
	}

	m_pset_a1p50_tag = 0;
	m_pset_a2p50_tag = 0;
}


void CFxStationDlg::OnBnClickedButton43()
{
	long targetID[35];
	targetID[0] = 105;
	targetID[1] = 106;
	targetID[2] = 102;
	targetID[3] = 103;
	targetID[4] = 104;
	targetID[5] = 105;
	targetID[6] = 106;


	targetID[7] = 110;
	targetID[8] = 111;
	targetID[9] = 112;
	targetID[10] = 113;
	targetID[11] = 114;
	targetID[12] = 115;
	targetID[13] = 116;


	targetID[14] = 150;
	targetID[15] = 151;
	targetID[16] = 152;
	targetID[17] = 153;
	targetID[18] = 154;
	targetID[19] = 155;
	targetID[20] = 156;

	targetID[21] = 176;

	CRobot::OnStartGather(2, targetID, 2000000);
}


void CFxStationDlg::OnBnClickedButton44()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);

	if (m_sendd_2_2.IsEmpty() == false)
	{
		unsigned char buf[256];
		memset(buf, 0, 256);
		long len = m_sendd_2_2.GetLength();
		if (len > 200)
		{
			len = 200;
		}
		for (long i = 0; i < len; i++)
		{
			buf[i] = m_sendd_2_2.GetAt(i);
		}

		if (m_hex_tag == true)
		{
			unsigned char buf2[256];
			memset(buf2, 0, 256);
			long hlen;
			if (AscIIToHex(buf, len, buf2, hlen) == false)
			{
				AfxMessageBox("FORMAT Err");
				return;
			}
			CRobot::OnSetChDataB(buf2, hlen, 2);
		}
		else
		{
			CRobot::OnSetChDataB(buf, len, 2);
		}
	}
}


void CFxStationDlg::OnBnClickedButton45()
{
	UpdateData(true);

	if (m_sendd_2_2.IsEmpty() == false)
	{
		unsigned char buf[256];
		memset(buf, 0, 256);
		long len = m_sendd_2_2.GetLength();
		if (len > 200)
		{
			len = 200;
		}
		for (long i = 0; i < len; i++)
		{
			buf[i] = m_sendd_2_2.GetAt(i);
		}

		if (m_hex_tag == true)
		{
			unsigned char buf2[256];
			memset(buf2, 0, 256);
			long hlen;
			if (AscIIToHex(buf, len, buf2, hlen) == false)
			{
				AfxMessageBox("FORMAT Err");
				return;
			}
			CRobot::OnSetChDataB(buf2, hlen, 3);

		}
		else
		{
			CRobot::OnSetChDataB(buf, len, 3);
		}
	}
}


void CFxStationDlg::OnBnClickedButton46()
{
	// TODO: 在此添加控件通知处理程序代码
	long targetID[35];
	targetID[0] = 100;
	targetID[1] = 101;
	targetID[2] = 102;
	targetID[3] = 103;
	targetID[4] = 104;
	targetID[5] = 105;
	targetID[6] = 106;
	CRobot::OnStartGather(7, targetID, 100000);
}




void CFxStationDlg::OnBnClickedButton47()
{
	UpdateData(true);
	if (m_sendd_2_1.IsEmpty() == false)
	{
		unsigned char buf[256];
		memset(buf, 0, 256);
		long len = m_sendd_2_1.GetLength();
		if (len > 200)
		{
			len = 200;
		}
		for (long i = 0; i < len; i++)
		{
			buf[i] = m_sendd_2_1.GetAt(i);
		}

		if (m_hex_tag == true)
		{
			unsigned char buf2[256];
			memset(buf2, 0, 256);
			long hlen;
			if (AscIIToHex(buf, len, buf2, hlen) == false)
			{
				AfxMessageBox("FORMAT Err");
				return;
			}
			
			CRobot::OnSetChDataA(buf2, hlen, 2);

		}
		else
		{
			CRobot::OnSetChDataA(buf, len, 2);
		}

		
	}
}


void CFxStationDlg::OnBnClickedButton48()
{
	UpdateData(true);
	if (m_sendd_2_1.IsEmpty() == false)
	{
		unsigned char buf[256];
		memset(buf, 0, 256);
		long len = m_sendd_2_1.GetLength();
		if (len > 200)
		{
			len = 200;
		}
		for (long i = 0; i < len; i++)
		{
			buf[i] = m_sendd_2_1.GetAt(i);
		}

		if (m_hex_tag == true)
		{
			unsigned char buf2[256];
			memset(buf2, 0, 256);
			long hlen;
			if (AscIIToHex(buf, len, buf2, hlen) == false)
			{
				AfxMessageBox("FORMAT Err");
				return;
			}
			CRobot::OnSetChDataA(buf2, hlen, 3);

		}
		else
		{
			CRobot::OnSetChDataA(buf, len, 3);
		}
		
	}
}


void CFxStationDlg::OnBnClickedUpdatesystembtn2()
{
	if (m_LinkTag == false)
	{
		return;
	}
	char name[30];
	long serial = 0;
	long type[2];
	double grv[2][3];
	double HD[2][8][4];
	double lmt[2][8][4];
	double mass[2][7];
	double mcp[2][7][3];
	double inertial[2][7][6];
	double BD[2][4][3];
	long i;
	for(serial = 0; serial < 2; serial ++)
	{
		memset(name, 0, 30);
		sprintf(name, "R.A%d.BASIC.Type", serial);
		if (CRobot::OnGetIntPara(name, &type[serial]) != 0)
		{
			CString s;
			s.Format("Get Parameter %s Err",name);
			AfxMessageBox(s);
			return;
		}
		
		sprintf(name, "R.A%d.BASIC.GravityX", serial);
		if (CRobot::OnGetFloatPara(name, &grv[serial][0]) != 0)
		{
			CString s;
			s.Format("Get Parameter %s Err", name);
			AfxMessageBox(s);
			return;
		}
		sprintf(name, "R.A%d.BASIC.GravityY", serial);
		if (CRobot::OnGetFloatPara(name, &grv[serial][1]) != 0)
		{
			CString s;
			s.Format("Get Parameter %s Err", name);
			AfxMessageBox(s);
			return;
		}
		sprintf(name, "R.A%d.BASIC.GravityZ", serial);
		if (CRobot::OnGetFloatPara(name, &grv[serial][2]) != 0)
		{
			CString s;
			s.Format("Get Parameter %s Err", name);
			AfxMessageBox(s);
			return;
		}
		

		for (i = 0; i < 7; i++)
		{
			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.BASIC.LimitNeg",serial, i);
			if (CRobot::OnGetFloatPara(name, &lmt[serial][i][0]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.BASIC.LimitPos", serial, i);
			if (CRobot::OnGetFloatPara(name, &lmt[serial][i][1]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.BASIC.VelMax", serial, i);
			if (CRobot::OnGetFloatPara(name, &lmt[serial][i][2]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.BASIC.AccMax", serial, i);
			if (CRobot::OnGetFloatPara(name, &lmt[serial][i][3]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.DH.Alpha", serial, i);
			if (CRobot::OnGetFloatPara(name, &HD[serial][i][0]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.DH.A", serial, i);
			if (CRobot::OnGetFloatPara(name, &HD[serial][i][1]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.DH.D", serial, i);
			if (CRobot::OnGetFloatPara(name, &HD[serial][i][2]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.DH.Theta", serial, i);
			if (CRobot::OnGetFloatPara(name, &HD[serial][i][3]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A%d.L%d.DYNAMIC.M", serial, i);
			if (CRobot::OnGetFloatPara(name, &mass[serial][i]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.MRX", serial, i);
			if (CRobot::OnGetFloatPara(name, &mcp[serial][i][0]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.MRY", serial, i);
			if (CRobot::OnGetFloatPara(name, &mcp[serial][i][1]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.MRZ", serial, i);
			if (CRobot::OnGetFloatPara(name, &mcp[serial][i][2]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}



			sprintf(name, "R.A%d.L%d.DYNAMIC.InertiaXX", serial, i);
			if (CRobot::OnGetFloatPara(name, &inertial[serial][i][0]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.InertiaXY", serial, i);
			if (CRobot::OnGetFloatPara(name, &inertial[serial][i][1]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.InertiaXZ", serial, i);
			if (CRobot::OnGetFloatPara(name, &inertial[serial][i][2]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.InertiaYY", serial, i);
			if (CRobot::OnGetFloatPara(name, &inertial[serial][i][3]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.InertiaYZ", serial, i);
			if (CRobot::OnGetFloatPara(name, &inertial[serial][i][4]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.L%d.DYNAMIC.InertiaZZ", serial, i);
			if (CRobot::OnGetFloatPara(name, &inertial[serial][i][5]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
		}

		for ( i = 0; i < 3; i++)
		{
			sprintf(name, "R.A%d.CTRL.BD67PP%d", serial, i);
			if (CRobot::OnGetFloatPara(name, &BD[serial][0][i]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.CTRL.BD67NP%d", serial, i);
			if (CRobot::OnGetFloatPara(name, &BD[serial][1][i]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.CTRL.BD67NN%d", serial, i);
			if (CRobot::OnGetFloatPara(name, &BD[serial][2][i]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			sprintf(name, "R.A%d.CTRL.BD67PN%d", serial, i);
			if (CRobot::OnGetFloatPara(name, &BD[serial][3][i]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
		}

	
		{
			memset(name, 0, 30);
			sprintf(name, "R.A%d.FLANGE.Alpha", serial);
			if (CRobot::OnGetFloatPara(name, &HD[serial][7][0]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A%d.FLANGE.A", serial);
			if (CRobot::OnGetFloatPara(name, &HD[serial][7][1]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.FLANGE.D", serial);
			if (CRobot::OnGetFloatPara(name, &HD[serial][7][2]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A%d.FLANGE.Theta", serial);
			if (CRobot::OnGetFloatPara(name, &HD[serial][7][3]) != 0)
			{
				CString s;
				s.Format("Get Parameter %s Err", name);
				AfxMessageBox(s);
				return;
			}
		}	

	}




	CFileDialog fd(false, NULL, NULL, 0, ".MvKDCfg|*.MvKDCfg");

	if (fd.DoModal() != IDOK)
	{
		return;
	}



	CString s = fd.GetPathName();
	if (s.Find(".MvKDCfg") == -1)
	{
		s += ".MvKDCfg";
	}

	FILE* fp = fopen(s.GetBufferSetLength(s.GetLength()+1),"wb");

	long j, k;

	for ( i = 0; i < 2; i++)
	{
		fprintf(fp, "%d,%lf,%lf,%lf,%c", type[i], grv[i][0], grv[i][1], grv[i][2],0x0a);
		for ( j = 0; j < 7; j++)
		{
			for (k = 0; k < 4; k++)
			{
				fprintf(fp, "%lf,", HD[i][j][k]);
			}
			for (k = 0; k < 4; k++)
			{
				fprintf(fp, "%lf,", lmt[i][j][k]);
			}
			fprintf(fp, "%lf,", mass[i][j]);
			for (k = 0; k < 3; k++)
			{
				fprintf(fp, "%lf,", mcp[i][j][k]);
			}
			for (k = 0; k < 6; k++)
			{
				fprintf(fp, "%lf,", inertial[i][j][k]);
			}
			fprintf(fp, "%c", 0x0a);
			
		}
		for (k = 0; k < 4; k++)
		{
			fprintf(fp, "%lf,", HD[i][7][k]);
		}

		fprintf(fp, "%c", 0x0a);

		for (j = 0; j < 4; j++)
		{
			for (k = 0; k < 3; k++)
			{
				fprintf(fp, "%lf,", BD[i][j][k]);
			}
			
			fprintf(fp, "%c",0x0a);

		}
	}

	fflush(fp);
	fclose(fp);


	AfxMessageBox("OK");

}


void CFxStationDlg::OnBnClickedCheck1()
{
	if (m_hex_tag == false)
	{
		m_hex_tag = true;
		m_is_hex.SetCheck(1);
	}
	else
	{
		m_hex_tag = false;
		m_is_hex.SetCheck(0);
	}
}


void CFxStationDlg::OnBnClickedButton49()
{
	// TODO: 在此添加控件通知处理程序代码
	CTypeSelDlg dlg;
	if (dlg.DoModal() != IDOK)
	{
		return;
	}
	if (dlg.m_settype == 1)
	{
		long type1 = dlg.m_type1;
		long type2 = dlg.m_type2;
		{
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.Type");
			if (CRobot::OnSetIntPara(name, type1) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}
		}
		{
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.Type");
			if (CRobot::OnSetIntPara(name, type2) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}
		}

		CRobot::OnSavePara();
	}
	if (dlg.m_settype == 2)
	{
		long type1 = dlg.m_plr1;
		long type2 = dlg.m_plr2;
		
		{
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.TerminalPolar");
			if (CRobot::OnSetIntPara(name, type1) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.TerminalType");
			if (CRobot::OnSetIntPara(name, 1) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

		}
		{
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.TerminalPolar");
			if (CRobot::OnSetIntPara(name, type2) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}
			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.TerminalType");
			if (CRobot::OnSetIntPara(name, 1) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}
		}

		


		CRobot::OnSavePara();
	}
	
	if (dlg.m_settype == 3)
	{
		if (dlg.m_useemg != -1)
		{
			long emgt = dlg.m_useemg;
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.BASIC.UseEMG");
			if (CRobot::OnSetIntPara(name, emgt) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

		}
	}



	if (dlg.m_settype == 4)
	{
		if (dlg.m_dfv == 0)
		{
			long emgt = 0;
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.DynFloatTag");
			if (CRobot::OnSetIntPara(name, emgt) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

		}
		else
		{
			long emgt = 1;
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.DynFloatTag");
			if (CRobot::OnSetIntPara(name, emgt) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.GYROSETA");
			double dv = dlg.m_dfa;
			if (CRobot::OnSetFloatPara(name, dv) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}


			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.GYROSETB");
			dv = dlg.m_dfb;
			if (CRobot::OnSetFloatPara(name, dv) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}


			memset(name, 0, 30);
			sprintf(name, "R.A0.BASIC.GYROSETC");
			dv = dlg.m_dfc;
			if (CRobot::OnSetFloatPara(name, dv) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

		}
	}


	if (dlg.m_settype == 5)
	{
		if (dlg.m_dfv == 0)
		{
			long emgt = 0;
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.DynFloatTag");
			if (CRobot::OnSetIntPara(name, emgt) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

		}
		else
		{
			long emgt = 1;
			char name[30];
			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.DynFloatTag");
			if (CRobot::OnSetIntPara(name, emgt) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.GYROSETA");
			double dv = dlg.m_dfa;
			if (CRobot::OnSetFloatPara(name, dv) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}


			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.GYROSETB");
			dv = dlg.m_dfb;
			if (CRobot::OnSetFloatPara(name, dv) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}


			memset(name, 0, 30);
			sprintf(name, "R.A1.BASIC.GYROSETC");
			dv = dlg.m_dfc;
			if (CRobot::OnSetFloatPara(name, dv) < 0)
			{
				AfxMessageBox("Set Err");
				return;
			}

		}
	}
	

}


void CFxStationDlg::OnBnClickedButton51()
{
	CFileDialog fd(false, NULL, NULL, 0, ".MvKDCfg|*.MvKDCfg");

	if (fd.DoModal() != IDOK)
	{
		return;
	}
	
	FX_INT32L TYPE[2];
	FX_DOUBLE GRV[2][3];
	FX_DOUBLE DH[2][8][4];
	FX_DOUBLE PNVA[2][7][4];
	FX_DOUBLE BD[2][4][3];

	FX_DOUBLE Mass[2][7];
	FX_DOUBLE MCP[2][7][3];
	FX_DOUBLE I[2][7][6];

	CString s = fd.GetPathName();
	if (s.Find(".MvKDCfg") == -1)
	{
		s += ".MvKDCfg";
	}


	FX_BOOL ret = LOADMvCfg(s.GetBufferSetLength(s.GetLength() + 1), TYPE, GRV, DH, PNVA, BD, Mass, MCP, I);
	if (ret == FX_FALSE)
	{
		printf("LOAD ERR\n");
	}
	else
	{

		printf("LOAD OK\n");
	}

	for (long i = 0; i < 7; i++)
	{
		m_RunLmt[0].m_pos_u[i] = PNVA[0][i][0];
		m_RunLmt[0].m_pos_l[i] = PNVA[0][i][1];

		m_RunLmt[1].m_pos_u[i] = PNVA[1][i][0];
		m_RunLmt[1].m_pos_l[i] = PNVA[1][i][1];
	}
	m_lmt_tag = true;

}


void CFxStationDlg::OnBnClickedButton50()
{
	// TODO: 在此添加控件通知处理程序代码

	UpdateData(true);
	if (m_sendd_2_1.IsEmpty() == false)
	{
		unsigned char buf[256];
		memset(buf, 0, 256);
		long len = m_sendd_2_1.GetLength();
		if (len > 200)
		{
			len = 200;
		}
		for (long i = 0; i < len; i++)
		{
			buf[i] = m_sendd_2_1.GetAt(i);
		}

		if (m_hex_tag == true)
		{
			unsigned char buf2[256];
			memset(buf2, 0, 256);
			long hlen;
			if (AscIIToHex(buf, len, buf2, hlen) == false)
			{
				AfxMessageBox("FORMAT Err");
				return;
			}
			CRobot::OnSetChDataA(buf2, hlen, 1);

		}
		else
		{
			CRobot::OnSetChDataA(buf, len, 1);
		}

	}
}


void CFxStationDlg::OnBnClickedButton52()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);

	if (m_sendd_2_2.IsEmpty() == false)
	{
		unsigned char buf[256];
		memset(buf, 0, 256);
		long len = m_sendd_2_2.GetLength();
		if (len > 200)
		{
			len = 200;
		}
		for (long i = 0; i < len; i++)
		{
			buf[i] = m_sendd_2_2.GetAt(i);
		}

		if (m_hex_tag == true)
		{
			unsigned char buf2[256];
			memset(buf2, 0, 256);
			long hlen;
			if (AscIIToHex(buf, len, buf2, hlen) == false)
			{
				AfxMessageBox("FORMAT Err");
				return;
			}
			CRobot::OnSetChDataB(buf2, hlen, 1);

		}
		else
		{
			CRobot::OnSetChDataB(buf, len, 1);
		}
	}
}


void CFxStationDlg::OnBnClickedButton53()
{
	CPointSet pset;
	if (pset.OnLoadFast((char*)"D:\\TMP\\station_gather.tmp") == false)
	{
		AfxMessageBox("Load D:\\TMP\\station_gather.tmp Err");
		return;
	}

	long dim = (long)pset.OnGetType();
	long num = pset.OnGetPointNum();

	
	if (dim == 30)
	{
		CPointSet pset2;
		pset2.OnInit(PotT_29d);

		double v[100];
		for (long i = 0; i < num; i++)
		{
			double* pv = pset.OnGetPoint(i);

			long j;

			v[0] = pv[23];
			for (j = 0; j < 7; j++)
			{
				v[1 + j] = pv[2 + j];
				v[8 + j] = 0;
				v[15 + j] = pv[2 + 7 + 7 + j];
				v[22 + j] = pv[2 + 7 + j];
			}


			pset2.OnSetPoint(v);
		}
		if (pset2.OnSaveCSV((char*)"D:\\TMP\\Gather_Data.csv") == false)
		{
			AfxMessageBox("Save D:\\TMP\\Gather_Data.csv ERR");
			return;
		}

	}
	else
	{
		CPointSet pset2;

		PoinType type2 = (PoinType)(dim - 2);
		pset2.OnInit(type2);

		double v[100];
		for (long i = 0; i < num; i++)
		{
			double* pv = pset.OnGetPoint(i);

			long j;
			for (j = 2; j < dim; j++)
			{
				v[j-2] = pv[j];
			}
			pset2.OnSetPoint(v);
		}
		if (pset2.OnSaveCSV((char*)"D:\\TMP\\Gather_Data.csv") == false)
		{
			AfxMessageBox("Save D:\\TMP\\Gather_Data.csv ERR");
			return;
		}
	}

	AfxMessageBox("Save D:\\TMP\\Gather_Data.csv");
}


void CFxStationDlg::OnBnClickedButton54()
{
	UpdateData(true);
	if (m_LinkTag == false)
	{
		return;
	}

	int v = m_head1;
	if (v < -6000)
	{
		v = -6000;
	}
	if (v >= 6000)
	{
		v = 6000;
	}
	CRobot::OnSetIntPara("EXMT0", v);
}


void CFxStationDlg::OnBnClickedButton55()
{
	UpdateData(true);
	if (m_LinkTag == false)
	{
		return;
	}

	int v = m_head2;
	if (v < -6000)
	{
		v = -6000;
	}
	if (v >= 6000)
	{
		v = 6000;
	}
	CRobot::OnSetIntPara("EXMT1", v);
}


void CFxStationDlg::OnBnClickedButton56()
{
	if (cyc_send_tag == 0)
	{
		cyc_send_tag = 1;
		cyc_send_cnt = 0;
	}
	else
	{
		cyc_send_tag = 0;
	}
}


void CFxStationDlg::OnBnClickedButton57()
{
	long targetID[35];
	targetID[0] = 50;
	targetID[1] = 51;
	targetID[2] = 52;
	targetID[3] = 3;
	targetID[4] = 4;
	targetID[5] = 5;
	targetID[6] = 6;

	targetID[7] = 90;
	targetID[8] = 91;
	targetID[9] = 92;
	targetID[10] = 93;
	targetID[11] = 94;
	targetID[12] = 95;
	targetID[13] = 96;
	CRobot::OnStartGather(3, targetID, 100000);
}


void CFxStationDlg::OnBnClickedButtonRunJTrace2()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_A(ARM_STATE_RELEASE);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnEnChangeEdit16()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CFxStationDlg::OnBnClickedButton58()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	char paraName[30];
	memset(paraName,0,30);
	sprintf(paraName, "BRAK0");
	CRobot::OnSetIntPara(paraName, 1);
}


void CFxStationDlg::OnBnClickedButton59()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}

	char paraName[30];
	memset(paraName, 0, 30);
	sprintf(paraName, "BRAK0");
	CRobot::OnSetIntPara(paraName, 2);
}


void CFxStationDlg::OnBnClickedButtonRunJTrace3()
{
	if (m_LinkTag == false)
	{
		return;
	}

	CRobot::OnClearSet();
	CRobot::OnSetTargetState_B(ARM_STATE_RELEASE);

	CRobot::OnSetSend();
}


void CFxStationDlg::OnBnClickedButton61()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}

	char paraName[30];
	memset(paraName, 0, 30);
	sprintf(paraName, "BRAK1");
	CRobot::OnSetIntPara(paraName, 2);
}


void CFxStationDlg::OnBnClickedButton60()
{
	if (m_LinkTag == false)
	{
		return;
	}
	char paraName[30];
	memset(paraName, 0, 30);
	sprintf(paraName, "BRAK1");
	CRobot::OnSetIntPara(paraName, 1);
}


void CFxStationDlg::OnBnClickedButton62()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_state_1B == ARM_STATE_POSITION
		|| m_state_1B == ARM_STATE_PVT
		|| m_state_1B == ARM_STATE_TORQ)
	{
		return;
	}

	UpdateData(true);
	if (m_qlqc0 < 0 || m_qlqc0 >6)
	{
		return;
	}
	CString s;
	s.Format("请求清除<左臂>第(%d)轴电机编码器<零位值>！", m_qlqc0+1);
	CString s1;
	s1.Format("请确认");
	{
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
	}

//	CRobot::OnSetIntPara("RESETMOTENC0", m_qlqc0);
	 

}



void CFxStationDlg::OnBnClickedButton64()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_state_1B == ARM_STATE_POSITION
		|| m_state_1B == ARM_STATE_PVT
		|| m_state_1B == ARM_STATE_TORQ)
	{
		return;
	}

	UpdateData(true);
	if (m_qlqc0 < 0 || m_qlqc0 >6)
	{
		return;
	}
	CString s;
	s.Format("请求清除<左臂>第(%d)轴电机（外）编码器<零位值>！", m_qlqc0 + 1);
	CString s1;
	s1.Format("请确认");
	{
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
	}

	CRobot::OnSetIntPara("RESETEXTENC0", m_qlqc0);

}


void CFxStationDlg::OnBnClickedButton66()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_state_1B == ARM_STATE_POSITION
		|| m_state_1B == ARM_STATE_PVT
		|| m_state_1B == ARM_STATE_TORQ)
	{
		return;
	}

	UpdateData(true);
	if (m_qlqc0 < 0 || m_qlqc0 >6)
	{
		return;
	}
	CString s;
	s.Format("请求清除<左臂>第(%d)轴电机编码器<错误码>！", m_qlqc0 + 1);
	CString s1;
	s1.Format("请确认");
	{
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
	}

	CRobot::OnSetIntPara("CLEARMOTENC0", m_qlqc0);
}



void CFxStationDlg::OnBnClickedButton63()
{
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_state_2B == ARM_STATE_POSITION
		|| m_state_2B == ARM_STATE_PVT
		|| m_state_2B == ARM_STATE_TORQ)
	{
		return;
	}

	UpdateData(true);
	if (m_qlqc1 < 0 || m_qlqc1 >6)
	{
		return;
	}
	CString s;
	s.Format("请求清除<右臂>第(%d)轴电机编码器<零位值>！", m_qlqc1 + 1);
	CString s1;
	s1.Format("请确认");
	{
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
	}

	CRobot::OnSetIntPara("RESETMOTENC1", m_qlqc1);

}
void CFxStationDlg::OnBnClickedButton65()
{
	// TODO: 在此添加控件通知处理程序代码
	if (m_LinkTag == false)
	{
		return;
	}
	if (m_state_2B == ARM_STATE_POSITION
		|| m_state_2B == ARM_STATE_PVT
		|| m_state_2B == ARM_STATE_TORQ)
	{
		return;
	}

	UpdateData(true);
	if (m_qlqc1 < 0 || m_qlqc1 >6)
	{
		return;
	}
	CString s;
	s.Format("请求清除<右臂>第(%d)轴电机编码器<零位值>！", m_qlqc1 + 1);
	CString s1;
	s1.Format("请确认");
	{
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, MB_OKCANCEL) != IDOK)
		{
			return;
		}
	}

	CRobot::OnSetIntPara("RESETEXTENC1", m_qlqc1);

}

void CFxStationDlg::OnBnClickedButton67()
{
	// TODO: 在此添加控件通知处理程序代码

	if (m_LinkTag == false)
	{
		return;
	}
	if (m_state_2B == ARM_STATE_POSITION
		|| m_state_2B == ARM_STATE_PVT
		|| m_state_2B == ARM_STATE_TORQ)
	{
		return;
	}

	UpdateData(true);
	if (m_qlqc1 < 0 || m_qlqc1 >6)
	{
		return;
	}
	CString s;
	s.Format("请求清除<右臂>第(%d)轴电机编码器<错误码>！", m_qlqc1 + 1);
	CString s1;
	s1.Format("请确认");
	{
		if (MessageBoxA(s, s1, 0) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, 0) != IDOK)
		{
			return;
		}
		if (MessageBoxA(s, s1, 0) != IDOK)
		{
			return;
		}
	}

	CRobot::OnSetIntPara("CLEARMOTENC1", m_qlqc1);
}


void CFxStationDlg::OnBnClickedButton68()
{
	// TODO: 在此添加控件通知处理程序代码
}
