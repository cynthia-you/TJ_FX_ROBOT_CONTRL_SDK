﻿// CSelPVTDlg.cpp: 实现文件
//

#include "pch.h"
#include "FxStation.h"
#include "afxdialogex.h"
#include "CSelPVTDlg.h"


// CSelPVTDlg 对话框

IMPLEMENT_DYNAMIC(CSelPVTDlg, CDialogEx)

CSelPVTDlg::CSelPVTDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_sid(0)
	, m_path(_T(""))
{
	m_ID = -1;
}

CSelPVTDlg::~CSelPVTDlg()
{
}

void CSelPVTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_sid);
	DDX_Text(pDX, IDC_EDIT1, m_path);
}


BEGIN_MESSAGE_MAP(CSelPVTDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CSelPVTDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON1, &CSelPVTDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CSelPVTDlg 消息处理程序


void CSelPVTDlg::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(true);
	if (m_sid <= 0 || m_sid > 100)
	{
		AfxMessageBox("ID [1-100]");
		return;
	}
	if (m_path.IsEmpty())
	{
		AfxMessageBox("EMPTY FILE");
		return;
	}
	m_ID = m_sid;
	m_Path = m_path;
	CDialogEx::OnOK();
}


void CSelPVTDlg::OnBnClickedButton1()
{
	// TODO: 在此添加控件通知处理程序代码

	CFileDialog fd(true, NULL, NULL, 0, ".FMV|*.FMV");

	if (fd.DoModal() != IDOK)
	{
		return;
	}

	CString s = fd.GetPathName();
	UpdateData(true);
	m_path = s;

	UpdateData(false);

}
