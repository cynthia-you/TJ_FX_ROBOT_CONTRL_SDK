﻿
// FxStationDlg.h: 头文件
//

#pragma once

#include "PointSet.h"
#include "Robot.h"

typedef struct
{
	double tool[10];
	double jk[7];
	double jd[7];
	double ck[7];
	double cd[7];
	double vel;
	double acc;
	double toolk[6];
}SetPara;

typedef struct
{
	SetPara  para[2];
	long cur_use;
}SetParas;


typedef struct
{
	double m_pos_l[7];
	double m_pos_u[7];
	double m_vel[7];
	double m_acc[7];
}RunLmt;

// CFxStationDlg 对话框
class CFxStationDlg : public CDialogEx
{
// 构造
public:

	bool m_hex_tag;
	bool m_lmt_tag;
	long old_bt_1;
	long old_bt_2;
	bool in_gather_1;
	bool in_gather_2;
	bool ITT;
	long in_dg_tag_1;
	long in_dg_tag_2;
	CFxStationDlg(CWnd* pParent = nullptr);	// 标准构造函数
// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FXSTATION_DIALOG };
#endif
	CString  m_Shows[20];
	long     m_ShowNum;
	long     m_ShpwPos;
	long      m_pset_a1p50_tag;
	CPointSet m_pset_a1p50;
	long      m_pset_a2p50_tag;
	CPointSet m_pset_a2p50;
	SetPara  m_Para;
	SetParas m_Paras;
	bool m_LinkTag;
	RunLmt   m_RunLmt[2];
	FX_INT32 m_state_1B;
	FX_INT32 m_state_2B;


	FX_INT32 m_TipDI_1;
	FX_INT32 m_TipDI_2;

	FX_INT32 m_LowSpdFlag_1;
	FX_INT32 m_LowSpdFlag_2;

	HWND hStatusWindow;

	long m_show_type;
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSettool();
	afx_msg void OnBnClickedButtonLink();
	bool OnLoadParaFile(char* path);
	bool OnSaveParaFile(char* path);

	void OnSaveP50(long serial, CString s);
	bool OnLoadPointsFile(char* path,long target);
	bool OnSavePointsFile(char* path, long target);

	bool OnGetLmt();

	bool OnCheckPVT(long serial, CPointSet * pset,char * path);
	CPointSet m_pset[2];


	void OnShowPara();
	double m_tool_m;
	afx_msg void OnBnClickedButtonParaSel1();
	afx_msg void OnBnClickedButtonParaSel2();
	afx_msg void OnBnClickedButtonToolsave();
	afx_msg void OnBnClickedButtonToolload();
	CComboBox m_cb1;
	CComboBox m_cb2;
	CString m_cyc_joint_edit;
	afx_msg void OnBnClickedButtonAddPoint1();
	afx_msg void OnBnClickedButtonAddPoint2();
	afx_msg void OnBnClickedButtonDelPoint1();
	afx_msg void OnBnClickedButtonDelPoint2();
	afx_msg void OnBnClickedButtonSavePoint1();
	afx_msg void OnBnClickedButtonSavePoint2();
	afx_msg void OnBnClickedButtonLoadPoint2();
	afx_msg void OnBnClickedButtonLoadPoint1();
	afx_msg void OnBnClickedButtonLoadCycFile1();
	CString m_cyc_file_1;
	CString m_cyc_file_2;
	afx_msg void OnBnClickedButtonLoadCycFile2();
	afx_msg void OnBnClickedButtonSendpvt1();
	afx_msg void OnBnClickedButtonSendpvt2();
	afx_msg void OnBnClickedButtonWorkPvt1();
	afx_msg void OnBnClickedButtonWorkPvt2();
	afx_msg void OnBnClickedButtonWorkPvt();
	CIPAddressCtrl m_ip;
	CButton m_linkbnt;
	long m_work_pvt_serial_1;
	afx_msg void OnBnClickedButtonRunPvt1();
	afx_msg void OnBnClickedButtonWorkJoint1();
	afx_msg void OnBnClickedButtonSetjkd();
	afx_msg void OnBnClickedButtonSetckd();
	afx_msg void OnBnClickedButtonSetvelacc();
	afx_msg void OnBnClickedButtonRunJTrace1();
	afx_msg void OnBnClickedButtonRunJKd1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	long m_sq_serial;
	double m_sq_offset;
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	CButton m_bt6;
	afx_msg void OnBnClickedButton6();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnCbnSelchangeCombo2();
	afx_msg void OnCbnDblclkCombo1();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButtonWorkCycfile1();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
	afx_msg void OnBnClickedButtonRunCKd2();
	afx_msg void OnBnClickedButtonRunJKd2();
	afx_msg void OnBnClickedButtonRunCKd1();
	afx_msg void OnBnClickedButtonRunPvt2();
	afx_msg void OnBnClickedButtonRunJointTrace2();
	afx_msg void OnEnChangeEdit6();
	long m_work_pvt_serial_2;
	afx_msg void OnBnClickedButtonWorkJoint2();
	double m_Force;
	double m_ForceLmt;
	afx_msg void OnBnClickedButton10();
	afx_msg void OnBnClickedButton11();
	afx_msg void OnBnClickedButton12();
	afx_msg void OnBnClickedButton13();
	afx_msg void OnBnClickedButtonRunFctrl1();
	afx_msg void OnBnClickedButton14();
	long m_EncSel;
	double m_Encoffset;
	afx_msg void OnBnClickedButton15();
	afx_msg void OnEnChangeEdit11();
	afx_msg void OnBnClickedButton16();
	afx_msg void OnBnClickedButton17();
	afx_msg void OnBnClickedButton18();
	afx_msg void OnBnClickedButton19();
	afx_msg void OnBnClickedButton20();
	afx_msg void OnEnChangeEdit5();
	afx_msg void OnBnClickedButton21();
	afx_msg void OnBnClickedButton22();
	afx_msg void OnBnClickedButton24();
	afx_msg void OnBnClickedButton23();
	afx_msg void OnBnClickedButton25();
	afx_msg void OnBnClickedButton26();
	afx_msg void OnBnClickedButton27();
	afx_msg void OnBnClickedButton28();
	afx_msg void OnBnClickedButton29();
	afx_msg void OnBnClickedButton30();
	afx_msg void OnBnClickedButton31();
	afx_msg void OnBnClickedButtonSetjkd2();
	afx_msg void OnBnClickedButton32();
	afx_msg void OnBnClickedButton33();
	afx_msg void OnBnClickedButton34();
	afx_msg void OnBnClickedButton35();
	afx_msg void OnBnClickedButton36();
	afx_msg void OnEnChangeEditToolM();
	afx_msg void OnEnChangeEditToolMcpx();
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnBnClickedButton37();
	afx_msg void OnBnClickedButton38();
	afx_msg void OnBnClickedButton39();
	afx_msg void OnBnClickedButton40();
	afx_msg void OnBnClickedButtonSetjkd3();
	afx_msg void OnBnClickedButtonSetjkd4();
	afx_msg void OnBnClickedButtonSetjkd5();
	afx_msg void OnBnClickedButtonSetjkd6();
	afx_msg void OnBnClickedButtonSetjkd7();
	afx_msg void OnBnClickedButtonSetjkd8();
	afx_msg void OnBnClickedButtonSetjkd9();
	afx_msg void OnBnClickedButtonSetjkd10();
	afx_msg void OnBnClickedButtonSetjkd11();
	afx_msg void OnBnClickedButtonSetjkd12();
	afx_msg void OnBnClickedButtonSetjkd13();
	afx_msg void OnBnClickedUpdatesystembtn();
	afx_msg void OnBnClickedDownloadlogbtn();
	afx_msg void OnBnClickedButtonRunFctrl2();
	CString m_drg1;
	CString m_drg2;
	afx_msg void OnBnClickedButton42();
	afx_msg void OnBnClickedButtonWorkCycfile2();
	afx_msg void OnBnClickedButtonWorkCycfile();
	afx_msg void OnBnClickedButton43();
	afx_msg void OnBnClickedButton44();
//	CEdit m_sendd;
//	CString m_recvd;
//	CString m_sendd;
	CString m_sendd_2_1;
	CString m_recv_2_1;
	afx_msg void OnBnClickedButton45();
	CString m_sendd_2_2;
	CString m_recv_2_2;
	afx_msg void OnBnClickedButton46();
	afx_msg void OnBnClickedButton47();
	afx_msg void OnBnClickedButton48();
	afx_msg void OnBnClickedUpdatesystembtn2();
	CButton m_is_hex;
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnBnClickedButton49();
	afx_msg void OnBnClickedButton51();
	afx_msg void OnBnClickedButton50();
	afx_msg void OnBnClickedButton52();
	afx_msg void OnBnClickedButton53();
	long m_head1;
	long m_head2;
	afx_msg void OnBnClickedButton54();
	afx_msg void OnBnClickedButton55();
	afx_msg void OnBnClickedButton56();
	afx_msg void OnBnClickedButton57();
	afx_msg void OnBnClickedButtonRunJTrace2();
	afx_msg void OnEnChangeEdit16();
	afx_msg void OnBnClickedButton58();
	afx_msg void OnBnClickedButton59();
	afx_msg void OnBnClickedButtonRunJTrace3();
	afx_msg void OnBnClickedButton61();
	afx_msg void OnBnClickedButton60();
	afx_msg void OnBnClickedButton62();
	long m_qlqc0;
	long m_qlqc1;
	afx_msg void OnBnClickedButton64();
	afx_msg void OnBnClickedButton63();
	afx_msg void OnBnClickedButton65();
	afx_msg void OnBnClickedButton66();
	afx_msg void OnBnClickedButton67();
	afx_msg void OnBnClickedButton68();
};
