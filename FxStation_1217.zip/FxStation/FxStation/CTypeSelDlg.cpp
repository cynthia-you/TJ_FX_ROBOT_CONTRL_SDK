﻿// CTypeSelDlg.cpp: 实现文件
//

#include "pch.h"
#include "FxStation.h"
#include "afxdialogex.h"
#include "CTypeSelDlg.h"


// CTypeSelDlg 对话框

IMPLEMENT_DYNAMIC(CTypeSelDlg, CDialogEx)

CTypeSelDlg::CTypeSelDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, m_gyro_A(0)
	, m_gyro_B(0)
	, m_gyro_C(0)
{
	m_useemg = -1;
}

CTypeSelDlg::~CTypeSelDlg()
{
}

void CTypeSelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CHECK1, cbt1);
	DDX_Control(pDX, IDC_CHECK2, cbt2);
	DDX_Control(pDX, IDC_CHECK3, cbt3);
	DDX_Control(pDX, IDC_CHECK4, cbt4);
	DDX_Control(pDX, IDC_CHECK5, cbt5);
	DDX_Control(pDX, IDC_CHECK6, cbt6);
	DDX_Control(pDX, IDC_CHECK7, cbt7);
	DDX_Control(pDX, IDC_CHECK8, cbt8);
	DDX_Control(pDX, IDC_CHECK_A, cbta);
	DDX_Control(pDX, IDC_CHECK_B, cbtb);
	DDX_Control(pDX, IDC_CHECK_A2, m_emg);
	DDX_Control(pDX, IDC_CHECK_A3, cbtc);
	DDX_Control(pDX, IDC_CHECK_A4, cbtd);
	DDX_Control(pDX, IDC_CHECK_A5, cbtE);
	DDX_Text(pDX, IDC_EDIT2, m_gyro_A);
	DDX_Text(pDX, IDC_EDIT18, m_gyro_B);
	DDX_Text(pDX, IDC_EDIT19, m_gyro_C);
	DDX_Control(pDX, IDC_CHECK_A6, m_df);
}


BEGIN_MESSAGE_MAP(CTypeSelDlg, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK1, &CTypeSelDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_CHECK2, &CTypeSelDlg::OnBnClickedCheck2)
	ON_BN_CLICKED(IDC_CHECK3, &CTypeSelDlg::OnBnClickedCheck3)
	ON_BN_CLICKED(IDC_CHECK4, &CTypeSelDlg::OnBnClickedCheck4)
	ON_BN_CLICKED(IDC_CHECK_A, &CTypeSelDlg::OnBnClickedCheckA)
	ON_BN_CLICKED(IDC_CHECK_B, &CTypeSelDlg::OnBnClickedCheckB)
	ON_BN_CLICKED(IDC_CHECK5, &CTypeSelDlg::OnBnClickedCheck5)
	ON_BN_CLICKED(IDC_CHECK6, &CTypeSelDlg::OnBnClickedCheck6)
	ON_BN_CLICKED(IDC_CHECK7, &CTypeSelDlg::OnBnClickedCheck7)
	ON_BN_CLICKED(IDC_CHECK8, &CTypeSelDlg::OnBnClickedCheck8)
	ON_BN_CLICKED(IDOK, &CTypeSelDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_CHECK_A2, &CTypeSelDlg::OnBnClickedCheckA2)
	ON_BN_CLICKED(IDC_CHECK_A3, &CTypeSelDlg::OnBnClickedCheckA3)
	ON_BN_CLICKED(IDC_CHECK_A4, &CTypeSelDlg::OnBnClickedCheckA4)
	ON_BN_CLICKED(IDC_CHECK_A5, &CTypeSelDlg::OnBnClickedCheckA5)
	ON_BN_CLICKED(IDC_CHECK_A6, &CTypeSelDlg::OnBnClickedCheckA6)
END_MESSAGE_MAP()


// CTypeSelDlg 消息处理程序


void CTypeSelDlg::OnBnClickedCheck1()
{
	// TODO: 在此添加控件通知处理程序代码
	cbt1.SetCheck(1);
	cbt2.SetCheck(0);
	m_type1 = 1007;
}


void CTypeSelDlg::OnBnClickedCheck2()
{
	// TODO: 在此添加控件通知处理程序代码

	cbt1.SetCheck(0);
	cbt2.SetCheck(1);
	m_type1 = 1017;
}


void CTypeSelDlg::OnBnClickedCheck3()
{
	// TODO: 在此添加控件通知处理程序代码

	cbt3.SetCheck(1);
	cbt4.SetCheck(0);
	m_type2 = 1007;

}


void CTypeSelDlg::OnBnClickedCheck4()
{
	// TODO: 在此添加控件通知处理程序代码

	cbt3.SetCheck(0);
	cbt4.SetCheck(1);
	m_type2 = 1017;
}


void CTypeSelDlg::OnBnClickedCheckA()
{
	// TODO: 在此添加控件通知处理程序代码

	cbta.SetCheck(1);
	cbtb.SetCheck(0);
	cbtc.SetCheck(0);
	cbtd.SetCheck(0);
	cbtE.SetCheck(0);
	m_settype = 1;
}


void CTypeSelDlg::OnBnClickedCheckB()
{
	// TODO: 在此添加控件通知处理程序代码

	cbta.SetCheck(0);
	cbtb.SetCheck(1);
	cbtc.SetCheck(0);
	cbtd.SetCheck(0);
	cbtE.SetCheck(0);
	m_settype = 2;
}


void CTypeSelDlg::OnBnClickedCheck5()
{
	// TODO: 在此添加控件通知处理程序代码

	cbt5.SetCheck(1);
	cbt6.SetCheck(0);
	m_plr1 = 0;
}


void CTypeSelDlg::OnBnClickedCheck6()
{
	// TODO: 在此添加控件通知处理程序代码


	cbt5.SetCheck(0);
	cbt6.SetCheck(1);
	m_plr1 = 1;
}


void CTypeSelDlg::OnBnClickedCheck7()
{
	// TODO: 在此添加控件通知处理程序代码

	cbt7.SetCheck(1);
	cbt8.SetCheck(0);
	m_plr2 = 0;
}


void CTypeSelDlg::OnBnClickedCheck8()
{
	// TODO: 在此添加控件通知处理程序代码

	cbt7.SetCheck(0);
	cbt8.SetCheck(1);
	m_plr2 = 1;
}


void CTypeSelDlg::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码'
	if (m_settype == 4 || m_settype == 5)
	{
		UpdateData(true);
		if (m_dfv == 1)
		{
			m_dfa = m_gyro_A;
			m_dfb = m_gyro_B;
			m_dfc = m_gyro_C;
		}
		else
		{
			m_dfa = 0;
			m_dfb = 0;
			m_dfc = 0;
		}

	}
	CDialogEx::OnOK();
}


void CTypeSelDlg::OnBnClickedCheckA2()
{
	// TODO: 在此添加控件通知处理程序代码
	m_useemg = m_emg.GetCheck();

}


void CTypeSelDlg::OnBnClickedCheckA3()
{
	// TODO: 在此添加控件通知处理程序代码

	cbta.SetCheck(0);
	cbtb.SetCheck(0);
	cbtc.SetCheck(1);
	cbtd.SetCheck(0);
	cbtE.SetCheck(0);
	m_settype = 3;
}


void CTypeSelDlg::OnBnClickedCheckA4()
{
	// TODO: 在此添加控件通知处理程序代码

	cbta.SetCheck(0);
	cbtb.SetCheck(0);
	cbtc.SetCheck(0);
	cbtd.SetCheck(1);
	cbtE.SetCheck(0);
	m_settype = 4;

}


void CTypeSelDlg::OnBnClickedCheckA5()
{

	cbta.SetCheck(0);
	cbtb.SetCheck(0);
	cbtc.SetCheck(0);
	cbtd.SetCheck(0);
	cbtE.SetCheck(1);
	m_settype = 5;
}


void CTypeSelDlg::OnBnClickedCheckA6()
{
	// TODO: 在此添加控件通知处理程序代码

	m_dfv = m_df.GetCheck();
}
